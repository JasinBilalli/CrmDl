-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 27, 2022 at 03:35 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `addanother_thing_n`
--

CREATE TABLE `addanother_thing_n` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `person_id` int(11) DEFAULT NULL,
  `leasing` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leasing_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_of_purchase` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placing_on_the_market` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `most_common` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redeemed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `km_stood` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `traffic_legal_protection` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deductible` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `glass_protection` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `carried` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parking_damage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_shop` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hour_breakdown_assistance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accident_coverage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `add_another_item_g`
--

CREATE TABLE `add_another_item_g` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `upload_policeFahrzeug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comparison_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentFahrenzug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `person_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonenumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pin` int(11) NOT NULL DEFAULT '0',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `online` tinyint(1) NOT NULL DEFAULT '0',
  `firsttime` tinyint(1) NOT NULL DEFAULT '1',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `phonenumber`, `pin`, `confirmed`, `online`, `firsttime`, `email_verified_at`, `password`, `created_at`, `updated_at`, `remember_token`) VALUES
(1, 'Nina', 'nina@gmail.com', NULL, 0, 0, 0, 1, NULL, '$2y$10$mgAbOs6.vPTQsnnbg05lYuSl816T.z.zY.Fc0XVwZwgH3zwwUJwJm', '2022-01-31 15:04:24', '2022-01-31 15:04:24', NULL),
(2, 'Albenit', 'admin@gmail.com', NULL, 1859, 0, 0, 1, NULL, '$2y$10$92Uvb9Lmf83jVHSK0HZ6Q.VcQHYt0ag8QMWtEQc9pd09ijCRXKELG', '2022-01-31 15:04:25', '2022-02-26 08:16:19', NULL),
(3, 'backoffice', 'backoffice@gmail.com', NULL, 3308, 0, 0, 1, NULL, '$2y$10$YqrCctcPkIiiWYQ6Lm/6L.GLvGQ6jhUGl/Q.8zy3q6SaBzQc2sFP6', '2022-01-31 15:04:25', '2022-02-26 13:51:24', NULL),
(4, 'salesmanager', 'salesmanager@gmail.com', NULL, 3555, 0, 0, 1, NULL, '$2y$10$4e/Q7oM1hRb.C4b5syXXYO97M1fATQypKA3W6kwJO1HPCKCt1pgbK', '2022-01-31 15:04:25', '2022-02-27 14:33:27', NULL),
(5, 'fs1', 'fs1@gmail.com', NULL, 4801, 0, 0, 1, NULL, '$2y$10$jddxlLCtzzRrHaMoE3s.GurKyPldEfy57y1LDV38f1m0Q5lwyUquG', '2022-01-31 15:04:25', '2022-02-27 14:34:25', NULL),
(6, 'fs2', 'fs2@gmail.com', NULL, 4611, 0, 0, 1, NULL, '$2y$10$mQnoxCpWHsg1nPTHGCRP2utk4v7ezqCoLeDxdy2VrYHUvVwB32Zw6', '2022-01-31 15:04:25', '2022-02-16 12:24:30', NULL),
(7, 'fs3', 'fs3@gmail.com', NULL, 6459, 0, 0, 1, NULL, '$2y$10$RKB5P7HOuoMY/mW.x..0B.U8GW7icth0LiyaBz84lhWYU7Qwa3Wri', '2022-01-31 15:04:25', '2022-02-09 08:15:01', NULL),
(8, 'fs4', 'fs4@gmail.com', NULL, 1474, 0, 0, 1, NULL, '$2y$10$LWeC6XrCI3HnTJpyFVP39OMfJuRQ6rYrDa28RCl1tk43I07efraq.', '2022-01-31 15:04:25', '2022-02-12 12:15:43', NULL),
(9, 'digital', 'digital@gmail.com', NULL, 7186, 0, 0, 1, NULL, '$2y$10$lTbQZzdmZsxbzsde3RoZj.lvvmV.F9jmsCIg8J4kMy/cmJCxEI9NG', '2022-01-31 15:04:25', '2022-02-05 08:08:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_appointments`
--

CREATE TABLE `admin_appointments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `family` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--

CREATE TABLE `campaigns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaigns`
--

INSERT INTO `campaigns` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'instagram', '2022-01-31 15:04:25', '2022-01-31 15:04:25'),
(2, 'facebook', '2022-01-31 15:04:25', '2022-01-31 15:04:25'),
(3, 'sanascout', '2022-01-31 15:04:25', '2022-01-31 15:04:25');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `costumer_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `chat` json DEFAULT NULL,
  `rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_conversations`
--

CREATE TABLE `chat_conversations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `private` tinyint(1) NOT NULL DEFAULT '1',
  `direct_message` tinyint(1) NOT NULL DEFAULT '0',
  `data` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_conversations`
--

INSERT INTO `chat_conversations` (`id`, `private`, `direct_message`, `data`, `created_at`, `updated_at`) VALUES
(1, 1, 0, '[]', '2022-02-04 17:12:24', '2022-02-04 17:12:24'),
(2, 1, 0, '[]', '2022-02-04 17:13:30', '2022-02-04 17:13:30'),
(3, 1, 0, '[]', '2022-02-04 17:16:48', '2022-02-04 17:16:48'),
(4, 1, 0, '[]', '2022-02-08 11:33:09', '2022-02-08 11:33:09'),
(5, 1, 0, '[]', '2022-02-14 07:20:39', '2022-02-14 07:20:39'),
(6, 1, 0, '[]', '2022-02-14 13:53:40', '2022-02-14 13:53:40'),
(7, 1, 0, '[]', '2022-02-14 14:40:17', '2022-02-14 14:40:17'),
(8, 1, 0, '[]', '2022-02-14 14:41:20', '2022-02-14 14:41:20'),
(9, 1, 0, '[]', '2022-02-16 11:41:54', '2022-02-16 11:41:54'),
(10, 1, 0, '[]', '2022-02-16 11:47:19', '2022-02-16 11:47:19'),
(11, 1, 0, '[]', '2022-02-16 11:47:37', '2022-02-16 11:47:37'),
(12, 1, 0, '[]', '2022-02-16 11:47:39', '2022-02-16 11:47:39'),
(13, 1, 0, '[]', '2022-02-16 11:49:50', '2022-02-16 11:49:50'),
(14, 1, 0, '[]', '2022-02-16 11:50:14', '2022-02-16 11:50:14'),
(15, 1, 0, '[]', '2022-02-16 11:50:16', '2022-02-16 11:50:16'),
(16, 1, 0, '[]', '2022-02-16 11:50:17', '2022-02-16 11:50:17'),
(17, 1, 0, '[]', '2022-02-16 11:50:37', '2022-02-16 11:50:37'),
(18, 1, 0, '[]', '2022-02-16 11:51:34', '2022-02-16 11:51:34'),
(19, 1, 0, '[]', '2022-02-16 11:51:45', '2022-02-16 11:51:45'),
(20, 1, 0, '[]', '2022-02-16 11:52:18', '2022-02-16 11:52:18'),
(21, 1, 0, '[]', '2022-02-16 11:52:26', '2022-02-16 11:52:26'),
(22, 1, 0, '[]', '2022-02-16 11:54:35', '2022-02-16 11:54:35'),
(23, 1, 0, '[]', '2022-02-16 11:55:33', '2022-02-16 11:55:33'),
(24, 1, 0, '[]', '2022-02-16 11:56:13', '2022-02-16 11:56:13'),
(25, 1, 0, '[]', '2022-02-16 11:56:52', '2022-02-16 11:56:52'),
(26, 1, 0, '[]', '2022-02-16 11:56:54', '2022-02-16 11:56:54'),
(27, 1, 0, '[]', '2022-02-16 11:56:56', '2022-02-16 11:56:56'),
(28, 1, 0, '[]', '2022-02-16 11:57:01', '2022-02-16 11:57:01'),
(29, 1, 0, '[]', '2022-02-16 11:57:06', '2022-02-16 11:57:06'),
(30, 1, 0, '[]', '2022-02-16 11:57:20', '2022-02-16 11:57:20'),
(31, 1, 0, '[]', '2022-02-16 11:58:13', '2022-02-16 11:58:13'),
(32, 1, 0, '[]', '2022-02-16 11:58:14', '2022-02-16 11:58:14'),
(33, 1, 0, '[]', '2022-02-16 12:02:32', '2022-02-16 12:02:32'),
(34, 1, 0, '[]', '2022-02-16 12:03:01', '2022-02-16 12:03:01'),
(35, 1, 0, '[]', '2022-02-16 12:03:03', '2022-02-16 12:03:03'),
(36, 1, 1, '[]', '2022-02-16 12:03:06', '2022-02-26 12:45:22'),
(37, 1, 0, '[]', '2022-02-23 12:58:21', '2022-02-23 12:58:21'),
(38, 1, 0, '[]', '2022-02-23 13:20:18', '2022-02-23 13:20:18'),
(39, 1, 0, '[]', '2022-02-24 13:12:52', '2022-02-24 13:12:52'),
(40, 1, 0, '[]', '2022-02-24 13:41:17', '2022-02-24 13:41:17'),
(41, 1, 0, '[]', '2022-02-24 13:43:48', '2022-02-24 13:43:48'),
(42, 1, 0, '[]', '2022-02-24 13:44:05', '2022-02-24 13:44:05'),
(43, 1, 0, '[]', '2022-02-24 14:03:31', '2022-02-24 14:03:31'),
(44, 1, 0, '[]', '2022-02-24 14:05:33', '2022-02-24 14:05:33'),
(45, 1, 0, '[]', '2022-02-24 14:05:57', '2022-02-24 14:05:57'),
(46, 1, 0, '[]', '2022-02-24 14:08:50', '2022-02-24 14:08:50'),
(47, 1, 0, '[]', '2022-02-24 14:08:55', '2022-02-24 14:08:55'),
(48, 1, 0, '[]', '2022-02-24 14:09:20', '2022-02-24 14:09:20'),
(49, 1, 0, '[]', '2022-02-24 14:09:21', '2022-02-24 14:09:21'),
(50, 1, 0, '[]', '2022-02-24 14:09:45', '2022-02-24 14:09:45'),
(51, 1, 0, '[]', '2022-02-24 14:09:50', '2022-02-24 14:09:50'),
(52, 1, 0, '[]', '2022-02-24 14:10:07', '2022-02-24 14:10:07'),
(53, 1, 0, '[]', '2022-02-24 14:10:12', '2022-02-24 14:10:12'),
(54, 1, 0, '[]', '2022-02-24 14:10:41', '2022-02-24 14:10:41'),
(55, 1, 0, '[]', '2022-02-24 14:11:01', '2022-02-24 14:11:01'),
(56, 1, 0, '[]', '2022-02-24 14:11:38', '2022-02-24 14:11:38'),
(57, 1, 0, '[]', '2022-02-24 14:14:02', '2022-02-24 14:14:02'),
(58, 1, 0, '[]', '2022-02-24 14:14:06', '2022-02-24 14:14:06'),
(59, 1, 0, '[]', '2022-02-24 14:14:18', '2022-02-24 14:14:18'),
(60, 1, 0, '[]', '2022-02-24 14:14:47', '2022-02-24 14:14:47'),
(61, 1, 0, '[]', '2022-02-24 14:15:04', '2022-02-24 14:15:04'),
(62, 1, 0, '[]', '2022-02-24 14:15:06', '2022-02-24 14:15:06'),
(63, 1, 0, '[]', '2022-02-24 14:15:14', '2022-02-24 14:15:14'),
(64, 1, 0, '[]', '2022-02-24 14:15:41', '2022-02-24 14:15:41'),
(65, 1, 0, '[]', '2022-02-24 14:15:43', '2022-02-24 14:15:43'),
(66, 1, 0, '[]', '2022-02-24 14:16:23', '2022-02-24 14:16:23'),
(67, 1, 0, '[]', '2022-02-24 14:16:41', '2022-02-24 14:16:41'),
(68, 1, 0, '[]', '2022-02-24 14:17:46', '2022-02-24 14:17:46'),
(69, 1, 0, '[]', '2022-02-24 14:17:48', '2022-02-24 14:17:48'),
(70, 1, 0, '[]', '2022-02-24 14:18:11', '2022-02-24 14:18:11'),
(71, 1, 0, '[]', '2022-02-24 14:18:20', '2022-02-24 14:18:20'),
(72, 1, 0, '[]', '2022-02-24 14:18:44', '2022-02-24 14:18:44'),
(73, 1, 0, '[]', '2022-02-24 14:25:50', '2022-02-24 14:25:50'),
(74, 1, 0, '[]', '2022-02-24 14:25:52', '2022-02-24 14:25:52'),
(75, 1, 0, '[]', '2022-02-24 14:26:28', '2022-02-24 14:26:28'),
(76, 1, 0, '[]', '2022-02-24 14:27:07', '2022-02-24 14:27:07'),
(77, 1, 0, '[]', '2022-02-24 14:27:12', '2022-02-24 14:27:12'),
(78, 1, 0, '[]', '2022-02-24 14:27:12', '2022-02-24 14:27:12'),
(79, 1, 0, '[]', '2022-02-24 14:27:21', '2022-02-24 14:27:21'),
(80, 1, 0, '[]', '2022-02-24 14:27:22', '2022-02-24 14:27:22'),
(81, 1, 0, '[]', '2022-02-24 14:27:37', '2022-02-24 14:27:37'),
(82, 1, 0, '[]', '2022-02-24 14:27:38', '2022-02-24 14:27:38'),
(83, 1, 0, '[]', '2022-02-24 14:28:46', '2022-02-24 14:28:46'),
(84, 1, 0, '[]', '2022-02-24 14:28:47', '2022-02-24 14:28:47'),
(85, 1, 0, '[]', '2022-02-24 14:30:02', '2022-02-24 14:30:02'),
(86, 1, 0, '[]', '2022-02-24 14:30:03', '2022-02-24 14:30:03'),
(87, 1, 0, '[]', '2022-02-25 11:27:40', '2022-02-25 11:27:40'),
(88, 1, 0, '[]', '2022-02-25 11:33:01', '2022-02-25 11:33:01'),
(89, 1, 0, '[]', '2022-02-25 11:35:53', '2022-02-25 11:35:53'),
(90, 1, 0, '[]', '2022-02-25 11:35:58', '2022-02-25 11:35:58'),
(91, 1, 0, '[]', '2022-02-25 11:36:00', '2022-02-25 11:36:00'),
(92, 1, 0, '[]', '2022-02-25 11:36:17', '2022-02-25 11:36:17'),
(93, 1, 0, '[]', '2022-02-25 11:43:15', '2022-02-25 11:43:15'),
(94, 1, 0, '[]', '2022-02-25 11:43:36', '2022-02-25 11:43:36'),
(95, 1, 0, '[]', '2022-02-25 11:43:56', '2022-02-25 11:43:56'),
(96, 1, 0, '[]', '2022-02-25 11:44:35', '2022-02-25 11:44:35'),
(97, 1, 0, '[]', '2022-02-25 11:45:46', '2022-02-25 11:45:46'),
(98, 1, 0, '[]', '2022-02-25 11:46:44', '2022-02-25 11:46:44'),
(99, 1, 0, '[]', '2022-02-25 11:49:52', '2022-02-25 11:49:52'),
(100, 1, 0, '[]', '2022-02-25 11:50:30', '2022-02-25 11:50:30'),
(101, 1, 1, '[]', '2022-02-25 11:50:36', '2022-02-26 11:39:33');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `participation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `body`, `conversation_id`, `participation_id`, `type`, `created_at`, `updated_at`) VALUES
(1, 'bulzart', 36, 72, 'file', '2022-02-16 12:03:06', '2022-02-16 12:03:06'),
(2, '1645016658_620cf652c249e.txt', 36, 72, 'file', '2022-02-16 12:04:18', '2022-02-16 12:04:18'),
(3, 'aaa', 36, 72, 'text', '2022-02-16 12:07:45', '2022-02-16 12:07:45'),
(4, '1645016876_620cf72c6c3ec.json', 36, 72, 'file', '2022-02-16 12:07:56', '2022-02-16 12:07:56'),
(5, 'so file', 36, 72, 'text', '2022-02-16 12:08:04', '2022-02-16 12:08:04'),
(6, 'testeest', 101, 202, 'file', '2022-02-25 11:50:37', '2022-02-25 11:50:37'),
(7, '1645793576_6218d12842819.docx', 101, 202, 'file', '2022-02-25 11:52:56', '2022-02-25 11:52:56'),
(8, 'bb', 101, 202, 'text', '2022-02-25 11:58:47', '2022-02-25 11:58:47'),
(9, 'a7', 101, 202, 'text', '2022-02-25 12:00:02', '2022-02-25 12:00:02'),
(10, 'ej', 101, 201, 'text', '2022-02-25 12:09:23', '2022-02-25 12:09:23'),
(11, 'jj', 101, 201, 'text', '2022-02-25 12:10:09', '2022-02-25 12:10:09'),
(12, '123', 101, 202, 'text', '2022-02-25 12:12:08', '2022-02-25 12:12:08'),
(13, '123', 101, 201, 'text', '2022-02-25 12:12:23', '2022-02-25 12:12:23'),
(14, 'fol', 101, 201, 'text', '2022-02-25 12:38:49', '2022-02-25 12:38:49'),
(15, 'ku je', 101, 202, 'text', '2022-02-25 12:38:57', '2022-02-25 12:38:57'),
(16, 'hej', 101, 201, 'text', '2022-02-25 12:39:11', '2022-02-25 12:39:11'),
(17, 'a', 101, 201, 'text', '2022-02-25 12:41:42', '2022-02-25 12:41:42'),
(18, 'a', 101, 201, 'text', '2022-02-25 12:41:43', '2022-02-25 12:41:43'),
(19, 'aa', 101, 201, 'text', '2022-02-25 12:41:44', '2022-02-25 12:41:44'),
(20, 'a', 101, 201, 'text', '2022-02-25 12:41:44', '2022-02-25 12:41:44'),
(21, 'a', 101, 201, 'text', '2022-02-25 12:41:45', '2022-02-25 12:41:45'),
(22, 'a', 101, 201, 'text', '2022-02-25 12:41:54', '2022-02-25 12:41:54'),
(23, 'a', 101, 201, 'text', '2022-02-25 12:41:54', '2022-02-25 12:41:54'),
(24, '7', 101, 201, 'text', '2022-02-25 12:41:56', '2022-02-25 12:41:56'),
(25, '1', 101, 201, 'text', '2022-02-25 12:41:57', '2022-02-25 12:41:57'),
(26, '2', 101, 201, 'text', '2022-02-25 12:41:58', '2022-02-25 12:41:58'),
(27, '1', 101, 201, 'text', '2022-02-25 12:43:35', '2022-02-25 12:43:35'),
(28, '2', 101, 201, 'text', '2022-02-25 12:43:36', '2022-02-25 12:43:36'),
(29, 'bu', 101, 201, 'text', '2022-02-25 12:46:27', '2022-02-25 12:46:27'),
(30, 'ko', 101, 201, 'text', '2022-02-25 12:46:32', '2022-02-25 12:46:32'),
(31, 'a', 101, 201, 'text', '2022-02-25 12:46:37', '2022-02-25 12:46:37'),
(32, 'c', 101, 201, 'text', '2022-02-25 12:49:27', '2022-02-25 12:49:27'),
(33, 'q', 101, 201, 'text', '2022-02-25 13:03:31', '2022-02-25 13:03:31'),
(34, 'sadasds', 101, 201, 'text', '2022-02-25 13:07:03', '2022-02-25 13:07:03'),
(35, 'sadasdsad', 101, 201, 'text', '2022-02-25 13:11:42', '2022-02-25 13:11:42'),
(36, 'sadasdasd', 101, 201, 'text', '2022-02-25 13:14:10', '2022-02-25 13:14:10'),
(37, 'asdasd', 101, 201, 'text', '2022-02-25 13:14:13', '2022-02-25 13:14:13'),
(38, 'asdasdsad', 101, 201, 'text', '2022-02-25 13:14:16', '2022-02-25 13:14:16'),
(39, 'fffffff', 101, 201, 'text', '2022-02-25 13:14:21', '2022-02-25 13:14:21'),
(40, 'asdasdsad', 101, 201, 'text', '2022-02-25 13:16:12', '2022-02-25 13:16:12'),
(41, 'ffasdasdqweqweqwewqe', 101, 201, 'text', '2022-02-25 13:16:20', '2022-02-25 13:16:20'),
(42, 'asdasdwe13213123', 101, 201, 'text', '2022-02-25 13:16:37', '2022-02-25 13:16:37'),
(43, '213213213', 101, 201, 'text', '2022-02-25 13:16:42', '2022-02-25 13:16:42'),
(44, 'asdasdasdasdasd', 101, 201, 'text', '2022-02-25 13:17:27', '2022-02-25 13:17:27'),
(45, 'sadasdasdasd', 101, 201, 'text', '2022-02-25 13:17:39', '2022-02-25 13:17:39'),
(46, 'sadasdasdas', 101, 201, 'text', '2022-02-25 13:30:58', '2022-02-25 13:30:58'),
(47, 'sadasdasdas', 101, 201, 'text', '2022-02-25 13:42:41', '2022-02-25 13:42:41'),
(48, 'me', 101, 201, 'text', '2022-02-25 13:44:02', '2022-02-25 13:44:02'),
(49, 'a', 101, 202, 'text', '2022-02-25 13:46:28', '2022-02-25 13:46:28'),
(50, 'okok', 101, 202, 'text', '2022-02-25 13:48:58', '2022-02-25 13:48:58'),
(51, 'hej', 101, 201, 'text', '2022-02-25 14:19:14', '2022-02-25 14:19:14'),
(52, '1645869809_6219faf164c2d.sql', 101, 201, 'file', '2022-02-26 09:03:29', '2022-02-26 09:03:29'),
(53, 'qwe', 101, 201, 'text', '2022-02-26 09:03:51', '2022-02-26 09:03:51'),
(54, '1645872119_621a03f7a34b1.html', 101, 201, 'file', '2022-02-26 09:41:59', '2022-02-26 09:41:59'),
(55, 'ahahhahha', 101, 201, 'text', '2022-02-26 09:43:17', '2022-02-26 09:43:17'),
(56, 'une', 101, 201, 'text', '2022-02-26 09:45:57', '2022-02-26 09:45:57'),
(57, '?', 101, 201, 'text', '2022-02-26 09:46:05', '2022-02-26 09:46:05'),
(58, '1645879149_621a1f6d2282c.xlsx', 101, 201, 'file', '2022-02-26 11:39:09', '2022-02-26 11:39:09'),
(59, 'a', 101, 201, 'text', '2022-02-26 11:39:33', '2022-02-26 11:39:33'),
(60, 'b', 36, 71, 'text', '2022-02-26 12:45:22', '2022-02-26 12:45:22');

-- --------------------------------------------------------

--
-- Table structure for table `chat_message_notifications`
--

CREATE TABLE `chat_message_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `message_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `participation_id` bigint(20) UNSIGNED NOT NULL,
  `is_seen` tinyint(1) NOT NULL DEFAULT '0',
  `is_sender` tinyint(1) NOT NULL DEFAULT '0',
  `flagged` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_message_notifications`
--

INSERT INTO `chat_message_notifications` (`id`, `message_id`, `messageable_id`, `messageable_type`, `conversation_id`, `participation_id`, `is_seen`, `is_sender`, `flagged`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:03:06', NULL, NULL),
(2, 1, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:03:06', NULL, NULL),
(3, 2, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:04:18', NULL, NULL),
(4, 2, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:04:18', NULL, NULL),
(5, 3, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:07:45', NULL, NULL),
(6, 3, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:07:45', NULL, NULL),
(7, 4, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:07:56', NULL, NULL),
(8, 4, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:07:56', NULL, NULL),
(9, 5, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:08:04', NULL, NULL),
(10, 5, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:08:04', NULL, NULL),
(11, 6, 2, 'App\\Models\\Admins', 101, 202, 1, 1, 0, '2022-02-25 11:50:37', NULL, NULL),
(12, 6, 5, 'App\\Models\\Admins', 101, 201, 0, 0, 0, '2022-02-25 11:50:37', NULL, NULL),
(13, 7, 2, 'App\\Models\\Admins', 101, 202, 1, 1, 0, '2022-02-25 11:52:56', NULL, NULL),
(14, 7, 5, 'App\\Models\\Admins', 101, 201, 0, 0, 0, '2022-02-25 11:52:56', NULL, NULL),
(15, 8, 2, 'App\\Models\\Admins', 101, 202, 1, 1, 0, '2022-02-25 11:58:47', NULL, NULL),
(16, 8, 5, 'App\\Models\\Admins', 101, 201, 0, 0, 0, '2022-02-25 11:58:47', NULL, NULL),
(17, 9, 2, 'App\\Models\\Admins', 101, 202, 1, 1, 0, '2022-02-25 12:00:02', NULL, NULL),
(18, 9, 5, 'App\\Models\\Admins', 101, 201, 0, 0, 0, '2022-02-25 12:00:02', NULL, NULL),
(19, 10, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:09:23', NULL, NULL),
(20, 10, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:09:23', NULL, NULL),
(21, 11, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:10:09', NULL, NULL),
(22, 11, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:10:09', NULL, NULL),
(23, 12, 2, 'App\\Models\\Admins', 101, 202, 1, 1, 0, '2022-02-25 12:12:08', NULL, NULL),
(24, 12, 5, 'App\\Models\\Admins', 101, 201, 0, 0, 0, '2022-02-25 12:12:08', NULL, NULL),
(25, 13, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:12:23', NULL, NULL),
(26, 13, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:12:23', NULL, NULL),
(27, 14, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:38:49', NULL, NULL),
(28, 14, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:38:49', NULL, NULL),
(29, 15, 2, 'App\\Models\\Admins', 101, 202, 1, 1, 0, '2022-02-25 12:38:57', NULL, NULL),
(30, 15, 5, 'App\\Models\\Admins', 101, 201, 0, 0, 0, '2022-02-25 12:38:57', NULL, NULL),
(31, 16, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:39:11', NULL, NULL),
(32, 16, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:39:11', NULL, NULL),
(33, 17, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:42', NULL, NULL),
(34, 17, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:42', NULL, NULL),
(35, 18, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:43', NULL, NULL),
(36, 18, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:43', NULL, NULL),
(37, 19, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:44', NULL, NULL),
(38, 19, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:44', NULL, NULL),
(39, 20, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:44', NULL, NULL),
(40, 20, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:44', NULL, NULL),
(41, 21, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:45', NULL, NULL),
(42, 21, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:45', NULL, NULL),
(43, 22, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:54', NULL, NULL),
(44, 22, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:54', NULL, NULL),
(45, 23, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:54', NULL, NULL),
(46, 23, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:54', NULL, NULL),
(47, 24, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:56', NULL, NULL),
(48, 24, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:56', NULL, NULL),
(49, 25, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:57', NULL, NULL),
(50, 25, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:57', NULL, NULL),
(51, 26, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:41:58', NULL, NULL),
(52, 26, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:41:58', NULL, NULL),
(53, 27, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:43:35', NULL, NULL),
(54, 27, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:43:35', NULL, NULL),
(55, 28, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:43:36', NULL, NULL),
(56, 28, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:43:36', NULL, NULL),
(57, 29, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:46:27', NULL, NULL),
(58, 29, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:46:27', NULL, NULL),
(59, 30, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:46:32', NULL, NULL),
(60, 30, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:46:32', NULL, NULL),
(61, 31, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:46:37', NULL, NULL),
(62, 31, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:46:37', NULL, NULL),
(63, 32, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 12:49:27', NULL, NULL),
(64, 32, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 12:49:27', NULL, NULL),
(65, 33, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:03:31', NULL, NULL),
(66, 33, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:03:31', NULL, NULL),
(67, 34, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:07:03', NULL, NULL),
(68, 34, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:07:03', NULL, NULL),
(69, 35, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:11:42', NULL, NULL),
(70, 35, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:11:42', NULL, NULL),
(71, 36, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:14:10', NULL, NULL),
(72, 36, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:14:10', NULL, NULL),
(73, 37, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:14:13', NULL, NULL),
(74, 37, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:14:13', NULL, NULL),
(75, 38, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:14:16', NULL, NULL),
(76, 38, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:14:16', NULL, NULL),
(77, 39, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:14:21', NULL, NULL),
(78, 39, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:14:21', NULL, NULL),
(79, 40, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:16:12', NULL, NULL),
(80, 40, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:16:12', NULL, NULL),
(81, 41, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:16:20', NULL, NULL),
(82, 41, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:16:20', NULL, NULL),
(83, 42, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:16:37', NULL, NULL),
(84, 42, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:16:37', NULL, NULL),
(85, 43, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:16:42', NULL, NULL),
(86, 43, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:16:42', NULL, NULL),
(87, 44, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:17:27', NULL, NULL),
(88, 44, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:17:27', NULL, NULL),
(89, 45, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:17:39', NULL, NULL),
(90, 45, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:17:39', NULL, NULL),
(91, 46, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:30:58', NULL, NULL),
(92, 46, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:30:58', NULL, NULL),
(93, 47, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:42:41', NULL, NULL),
(94, 47, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:42:41', NULL, NULL),
(95, 48, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 13:44:02', NULL, NULL),
(96, 48, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 13:44:02', NULL, NULL),
(97, 49, 2, 'App\\Models\\Admins', 101, 202, 1, 1, 0, '2022-02-25 13:46:28', NULL, NULL),
(98, 49, 5, 'App\\Models\\Admins', 101, 201, 0, 0, 0, '2022-02-25 13:46:28', NULL, NULL),
(99, 50, 2, 'App\\Models\\Admins', 101, 202, 1, 1, 0, '2022-02-25 13:48:58', NULL, NULL),
(100, 50, 5, 'App\\Models\\Admins', 101, 201, 0, 0, 0, '2022-02-25 13:48:58', NULL, NULL),
(101, 51, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-25 14:19:14', NULL, NULL),
(102, 51, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-25 14:19:14', NULL, NULL),
(103, 52, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-26 09:03:29', NULL, NULL),
(104, 52, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-26 09:03:29', NULL, NULL),
(105, 53, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-26 09:03:51', NULL, NULL),
(106, 53, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-26 09:03:51', NULL, NULL),
(107, 54, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-26 09:41:59', NULL, NULL),
(108, 54, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-26 09:41:59', NULL, NULL),
(109, 55, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-26 09:43:17', NULL, NULL),
(110, 55, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-26 09:43:17', NULL, NULL),
(111, 56, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-26 09:45:57', NULL, NULL),
(112, 56, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-26 09:45:57', NULL, NULL),
(113, 57, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-26 09:46:05', NULL, NULL),
(114, 57, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-26 09:46:05', NULL, NULL),
(115, 58, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-26 11:39:09', NULL, NULL),
(116, 58, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-26 11:39:09', NULL, NULL),
(117, 59, 2, 'App\\Models\\Admins', 101, 202, 0, 0, 0, '2022-02-26 11:39:33', NULL, NULL),
(118, 59, 5, 'App\\Models\\Admins', 101, 201, 1, 1, 0, '2022-02-26 11:39:33', NULL, NULL),
(119, 60, 3, 'App\\Models\\Admins', 36, 72, 0, 0, 0, '2022-02-26 12:45:22', NULL, NULL),
(120, 60, 5, 'App\\Models\\Admins', 36, 71, 1, 1, 0, '2022-02-26 12:45:22', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat_participation`
--

CREATE TABLE `chat_participation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_participation`
--

INSERT INTO `chat_participation` (`id`, `conversation_id`, `messageable_id`, `messageable_type`, `settings`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 'App\\Models\\Admins', NULL, '2022-02-04 17:12:24', '2022-02-04 17:12:24'),
(2, 1, 3, 'App\\Models\\Admins', NULL, '2022-02-04 17:12:24', '2022-02-04 17:12:24'),
(3, 2, 5, 'App\\Models\\Admins', NULL, '2022-02-04 17:13:30', '2022-02-04 17:13:30'),
(4, 2, 3, 'App\\Models\\Admins', NULL, '2022-02-04 17:13:30', '2022-02-04 17:13:30'),
(5, 3, 5, 'App\\Models\\Admins', NULL, '2022-02-04 17:16:48', '2022-02-04 17:16:48'),
(6, 3, 3, 'App\\Models\\Admins', NULL, '2022-02-04 17:16:48', '2022-02-04 17:16:48'),
(7, 4, 6, 'App\\Models\\Admins', NULL, '2022-02-08 11:33:09', '2022-02-08 11:33:09'),
(8, 4, 3, 'App\\Models\\Admins', NULL, '2022-02-08 11:33:09', '2022-02-08 11:33:09'),
(9, 5, 5, 'App\\Models\\Admins', NULL, '2022-02-14 07:20:39', '2022-02-14 07:20:39'),
(10, 5, 3, 'App\\Models\\Admins', NULL, '2022-02-14 07:20:39', '2022-02-14 07:20:39'),
(11, 6, 5, 'App\\Models\\Admins', NULL, '2022-02-14 13:53:40', '2022-02-14 13:53:40'),
(12, 6, 3, 'App\\Models\\Admins', NULL, '2022-02-14 13:53:40', '2022-02-14 13:53:40'),
(13, 7, 5, 'App\\Models\\Admins', NULL, '2022-02-14 14:40:17', '2022-02-14 14:40:17'),
(14, 7, 3, 'App\\Models\\Admins', NULL, '2022-02-14 14:40:17', '2022-02-14 14:40:17'),
(15, 8, 5, 'App\\Models\\Admins', NULL, '2022-02-14 14:41:20', '2022-02-14 14:41:20'),
(16, 8, 3, 'App\\Models\\Admins', NULL, '2022-02-14 14:41:20', '2022-02-14 14:41:20'),
(17, 9, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:41:54', '2022-02-16 11:41:54'),
(18, 9, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:41:54', '2022-02-16 11:41:54'),
(19, 10, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:19', '2022-02-16 11:47:19'),
(20, 10, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:19', '2022-02-16 11:47:19'),
(21, 11, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:37', '2022-02-16 11:47:37'),
(22, 11, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:37', '2022-02-16 11:47:37'),
(23, 12, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:39', '2022-02-16 11:47:39'),
(24, 12, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:39', '2022-02-16 11:47:39'),
(25, 13, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:49:50', '2022-02-16 11:49:50'),
(26, 13, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:49:50', '2022-02-16 11:49:50'),
(27, 14, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:14', '2022-02-16 11:50:14'),
(28, 14, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:14', '2022-02-16 11:50:14'),
(29, 15, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:16', '2022-02-16 11:50:16'),
(30, 15, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:16', '2022-02-16 11:50:16'),
(31, 16, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:17', '2022-02-16 11:50:17'),
(32, 16, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:17', '2022-02-16 11:50:17'),
(33, 17, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:37', '2022-02-16 11:50:37'),
(34, 17, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:37', '2022-02-16 11:50:37'),
(35, 18, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:51:34', '2022-02-16 11:51:34'),
(36, 18, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:51:34', '2022-02-16 11:51:34'),
(37, 19, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:51:45', '2022-02-16 11:51:45'),
(38, 19, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:51:45', '2022-02-16 11:51:45'),
(39, 20, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:52:18', '2022-02-16 11:52:18'),
(40, 20, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:52:18', '2022-02-16 11:52:18'),
(41, 21, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:52:26', '2022-02-16 11:52:26'),
(42, 21, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:52:26', '2022-02-16 11:52:26'),
(43, 22, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:54:35', '2022-02-16 11:54:35'),
(44, 22, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:54:35', '2022-02-16 11:54:35'),
(45, 23, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:55:33', '2022-02-16 11:55:33'),
(46, 23, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:55:33', '2022-02-16 11:55:33'),
(47, 24, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:13', '2022-02-16 11:56:13'),
(48, 24, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:13', '2022-02-16 11:56:13'),
(49, 25, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:52', '2022-02-16 11:56:52'),
(50, 25, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:52', '2022-02-16 11:56:52'),
(51, 26, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:54', '2022-02-16 11:56:54'),
(52, 26, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:54', '2022-02-16 11:56:54'),
(53, 27, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:56', '2022-02-16 11:56:56'),
(54, 27, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:56', '2022-02-16 11:56:56'),
(55, 28, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:01', '2022-02-16 11:57:01'),
(56, 28, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:01', '2022-02-16 11:57:01'),
(57, 29, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:06', '2022-02-16 11:57:06'),
(58, 29, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:06', '2022-02-16 11:57:06'),
(59, 30, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:20', '2022-02-16 11:57:20'),
(60, 30, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:20', '2022-02-16 11:57:20'),
(61, 31, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:58:13', '2022-02-16 11:58:13'),
(62, 31, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:58:13', '2022-02-16 11:58:13'),
(63, 32, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:58:14', '2022-02-16 11:58:14'),
(64, 32, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:58:14', '2022-02-16 11:58:14'),
(65, 33, 5, 'App\\Models\\Admins', NULL, '2022-02-16 12:02:32', '2022-02-16 12:02:32'),
(66, 33, 3, 'App\\Models\\Admins', NULL, '2022-02-16 12:02:32', '2022-02-16 12:02:32'),
(67, 34, 5, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:01', '2022-02-16 12:03:01'),
(68, 34, 3, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:01', '2022-02-16 12:03:01'),
(69, 35, 5, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:03', '2022-02-16 12:03:03'),
(70, 35, 3, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:03', '2022-02-16 12:03:03'),
(71, 36, 5, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:06', '2022-02-16 12:03:06'),
(72, 36, 3, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:06', '2022-02-16 12:03:06'),
(73, 37, 5, 'App\\Models\\Admins', NULL, '2022-02-23 12:58:21', '2022-02-23 12:58:21'),
(74, 37, 2, 'App\\Models\\Admins', NULL, '2022-02-23 12:58:21', '2022-02-23 12:58:21'),
(75, 38, 5, 'App\\Models\\Admins', NULL, '2022-02-23 13:20:18', '2022-02-23 13:20:18'),
(76, 38, 2, 'App\\Models\\Admins', NULL, '2022-02-23 13:20:18', '2022-02-23 13:20:18'),
(77, 39, 5, 'App\\Models\\Admins', NULL, '2022-02-24 13:12:52', '2022-02-24 13:12:52'),
(78, 39, 2, 'App\\Models\\Admins', NULL, '2022-02-24 13:12:52', '2022-02-24 13:12:52'),
(79, 40, 5, 'App\\Models\\Admins', NULL, '2022-02-24 13:41:17', '2022-02-24 13:41:17'),
(80, 40, 2, 'App\\Models\\Admins', NULL, '2022-02-24 13:41:17', '2022-02-24 13:41:17'),
(81, 41, 5, 'App\\Models\\Admins', NULL, '2022-02-24 13:43:48', '2022-02-24 13:43:48'),
(82, 41, 2, 'App\\Models\\Admins', NULL, '2022-02-24 13:43:48', '2022-02-24 13:43:48'),
(83, 42, 5, 'App\\Models\\Admins', NULL, '2022-02-24 13:44:05', '2022-02-24 13:44:05'),
(84, 42, 2, 'App\\Models\\Admins', NULL, '2022-02-24 13:44:05', '2022-02-24 13:44:05'),
(85, 43, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:03:31', '2022-02-24 14:03:31'),
(86, 43, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:03:31', '2022-02-24 14:03:31'),
(87, 44, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:05:33', '2022-02-24 14:05:33'),
(88, 44, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:05:33', '2022-02-24 14:05:33'),
(89, 45, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:05:57', '2022-02-24 14:05:57'),
(90, 45, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:05:57', '2022-02-24 14:05:57'),
(91, 46, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:08:50', '2022-02-24 14:08:50'),
(92, 46, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:08:50', '2022-02-24 14:08:50'),
(93, 47, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:08:55', '2022-02-24 14:08:55'),
(94, 47, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:08:55', '2022-02-24 14:08:55'),
(95, 48, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:09:20', '2022-02-24 14:09:20'),
(96, 48, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:09:20', '2022-02-24 14:09:20'),
(97, 49, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:09:21', '2022-02-24 14:09:21'),
(98, 49, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:09:21', '2022-02-24 14:09:21'),
(99, 50, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:09:45', '2022-02-24 14:09:45'),
(100, 50, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:09:45', '2022-02-24 14:09:45'),
(101, 51, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:09:50', '2022-02-24 14:09:50'),
(102, 51, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:09:50', '2022-02-24 14:09:50'),
(103, 52, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:10:07', '2022-02-24 14:10:07'),
(104, 52, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:10:07', '2022-02-24 14:10:07'),
(105, 53, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:10:12', '2022-02-24 14:10:12'),
(106, 53, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:10:12', '2022-02-24 14:10:12'),
(107, 54, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:10:41', '2022-02-24 14:10:41'),
(108, 54, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:10:41', '2022-02-24 14:10:41'),
(109, 55, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:11:01', '2022-02-24 14:11:01'),
(110, 55, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:11:01', '2022-02-24 14:11:01'),
(111, 56, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:11:38', '2022-02-24 14:11:38'),
(112, 56, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:11:38', '2022-02-24 14:11:38'),
(113, 57, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:14:02', '2022-02-24 14:14:02'),
(114, 57, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:14:02', '2022-02-24 14:14:02'),
(115, 58, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:14:06', '2022-02-24 14:14:06'),
(116, 58, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:14:06', '2022-02-24 14:14:06'),
(117, 59, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:14:18', '2022-02-24 14:14:18'),
(118, 59, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:14:18', '2022-02-24 14:14:18'),
(119, 60, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:14:47', '2022-02-24 14:14:47'),
(120, 60, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:14:47', '2022-02-24 14:14:47'),
(121, 61, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:04', '2022-02-24 14:15:04'),
(122, 61, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:04', '2022-02-24 14:15:04'),
(123, 62, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:06', '2022-02-24 14:15:06'),
(124, 62, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:06', '2022-02-24 14:15:06'),
(125, 63, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:14', '2022-02-24 14:15:14'),
(126, 63, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:14', '2022-02-24 14:15:14'),
(127, 64, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:41', '2022-02-24 14:15:41'),
(128, 64, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:41', '2022-02-24 14:15:41'),
(129, 65, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:43', '2022-02-24 14:15:43'),
(130, 65, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:15:43', '2022-02-24 14:15:43'),
(131, 66, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:16:23', '2022-02-24 14:16:23'),
(132, 66, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:16:23', '2022-02-24 14:16:23'),
(133, 67, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:16:41', '2022-02-24 14:16:41'),
(134, 67, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:16:41', '2022-02-24 14:16:41'),
(135, 68, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:17:46', '2022-02-24 14:17:46'),
(136, 68, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:17:46', '2022-02-24 14:17:46'),
(137, 69, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:17:48', '2022-02-24 14:17:48'),
(138, 69, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:17:48', '2022-02-24 14:17:48'),
(139, 70, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:18:11', '2022-02-24 14:18:11'),
(140, 70, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:18:11', '2022-02-24 14:18:11'),
(141, 71, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:18:20', '2022-02-24 14:18:20'),
(142, 71, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:18:20', '2022-02-24 14:18:20'),
(143, 72, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:18:44', '2022-02-24 14:18:44'),
(144, 72, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:18:44', '2022-02-24 14:18:44'),
(145, 73, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:25:50', '2022-02-24 14:25:50'),
(146, 73, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:25:50', '2022-02-24 14:25:50'),
(147, 74, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:25:52', '2022-02-24 14:25:52'),
(148, 74, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:25:52', '2022-02-24 14:25:52'),
(149, 75, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:26:28', '2022-02-24 14:26:28'),
(150, 75, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:26:28', '2022-02-24 14:26:28'),
(151, 76, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:07', '2022-02-24 14:27:07'),
(152, 76, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:07', '2022-02-24 14:27:07'),
(153, 77, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:12', '2022-02-24 14:27:12'),
(154, 77, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:12', '2022-02-24 14:27:12'),
(155, 78, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:12', '2022-02-24 14:27:12'),
(156, 78, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:12', '2022-02-24 14:27:12'),
(157, 79, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:21', '2022-02-24 14:27:21'),
(158, 79, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:21', '2022-02-24 14:27:21'),
(159, 80, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:22', '2022-02-24 14:27:22'),
(160, 80, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:22', '2022-02-24 14:27:22'),
(161, 81, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:37', '2022-02-24 14:27:37'),
(162, 81, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:37', '2022-02-24 14:27:37'),
(163, 82, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:38', '2022-02-24 14:27:38'),
(164, 82, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:27:38', '2022-02-24 14:27:38'),
(165, 83, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:28:46', '2022-02-24 14:28:46'),
(166, 83, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:28:46', '2022-02-24 14:28:46'),
(167, 84, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:28:47', '2022-02-24 14:28:47'),
(168, 84, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:28:47', '2022-02-24 14:28:47'),
(169, 85, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:30:02', '2022-02-24 14:30:02'),
(170, 85, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:30:02', '2022-02-24 14:30:02'),
(171, 86, 5, 'App\\Models\\Admins', NULL, '2022-02-24 14:30:03', '2022-02-24 14:30:03'),
(172, 86, 2, 'App\\Models\\Admins', NULL, '2022-02-24 14:30:03', '2022-02-24 14:30:03'),
(173, 87, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:27:40', '2022-02-25 11:27:40'),
(174, 87, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:27:40', '2022-02-25 11:27:40'),
(175, 88, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:33:01', '2022-02-25 11:33:01'),
(176, 88, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:33:01', '2022-02-25 11:33:01'),
(177, 89, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:35:53', '2022-02-25 11:35:53'),
(178, 89, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:35:53', '2022-02-25 11:35:53'),
(179, 90, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:35:58', '2022-02-25 11:35:58'),
(180, 90, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:35:58', '2022-02-25 11:35:58'),
(181, 91, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:36:00', '2022-02-25 11:36:00'),
(182, 91, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:36:00', '2022-02-25 11:36:00'),
(183, 92, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:36:17', '2022-02-25 11:36:17'),
(184, 92, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:36:17', '2022-02-25 11:36:17'),
(185, 93, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:43:15', '2022-02-25 11:43:15'),
(186, 93, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:43:15', '2022-02-25 11:43:15'),
(187, 94, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:43:36', '2022-02-25 11:43:36'),
(188, 94, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:43:36', '2022-02-25 11:43:36'),
(189, 95, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:43:56', '2022-02-25 11:43:56'),
(190, 95, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:43:56', '2022-02-25 11:43:56'),
(191, 96, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:44:35', '2022-02-25 11:44:35'),
(192, 96, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:44:35', '2022-02-25 11:44:35'),
(193, 97, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:45:46', '2022-02-25 11:45:46'),
(194, 97, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:45:46', '2022-02-25 11:45:46'),
(195, 98, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:46:44', '2022-02-25 11:46:44'),
(196, 98, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:46:44', '2022-02-25 11:46:44'),
(197, 99, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:49:52', '2022-02-25 11:49:52'),
(198, 99, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:49:52', '2022-02-25 11:49:52'),
(199, 100, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:50:30', '2022-02-25 11:50:30'),
(200, 100, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:50:30', '2022-02-25 11:50:30'),
(201, 101, 5, 'App\\Models\\Admins', NULL, '2022-02-25 11:50:36', '2022-02-25 11:50:36'),
(202, 101, 2, 'App\\Models\\Admins', NULL, '2022-02-25 11:50:36', '2022-02-25 11:50:36');

-- --------------------------------------------------------

--
-- Table structure for table `costumers`
--

CREATE TABLE `costumers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateofbirth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `mandated` tinyint(1) DEFAULT NULL,
  `actions` json NOT NULL,
  `birthday` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `civilstatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kvg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vvg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `health` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_podukt_zusatzversicherung`
--

CREATE TABLE `costumer_podukt_zusatzversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PZ` int(11) DEFAULT NULL,
  `graduation_date_PZ` date DEFAULT NULL,
  `society_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produkt_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vvg_premium_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_from_PZ` date DEFAULT NULL,
  `duration_to_PZ` date DEFAULT NULL,
  `status_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PZ` date DEFAULT NULL,
  `provision_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produkt_PZ2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vvg_premium_PZ2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_from_PZ2` date DEFAULT NULL,
  `duration_to_PZ2` date DEFAULT NULL,
  `status_PZ2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PZ2` date DEFAULT NULL,
  `provision_PZ2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_commisions_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_autoversicherung`
--

CREATE TABLE `costumer_produkt_autoversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PA` int(11) DEFAULT NULL,
  `society_PA` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `beginning_insurance_PA` date DEFAULT NULL,
  `insurance_PA` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PA` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PA` date DEFAULT NULL,
  `total_commisions_PA` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_grundversicherung`
--

CREATE TABLE `costumer_produkt_grundversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PG` int(11) DEFAULT NULL,
  `graduation_date_PG` date DEFAULT NULL,
  `society_PG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_PG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PG` date DEFAULT NULL,
  `total_commisions_PG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_hausrat`
--

CREATE TABLE `costumer_produkt_hausrat` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PH` int(11) DEFAULT NULL,
  `society_PH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `beginning_insurance_PH` date DEFAULT NULL,
  `insurance_PH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PH` date DEFAULT NULL,
  `total_commisions_PH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_rechtsschutz`
--

CREATE TABLE `costumer_produkt_rechtsschutz` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PR` int(11) DEFAULT NULL,
  `graduation_date_PR` date DEFAULT NULL,
  `society_PR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produkt_PR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PR` date DEFAULT NULL,
  `total_commisions_PR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_vorsorge`
--

CREATE TABLE `costumer_produkt_vorsorge` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PV` int(11) DEFAULT NULL,
  `graduation_date_PV` date DEFAULT NULL,
  `begin_PV` date DEFAULT NULL,
  `society_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pramie_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_rythm_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_from_PV` date DEFAULT NULL,
  `duration_to_PV` date DEFAULT NULL,
  `production_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PV` date DEFAULT NULL,
  `total_commisions_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_grundversicherung`
--

CREATE TABLE `costumer_status_grundversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idG` int(11) DEFAULT NULL,
  `societyG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kvg_premiumG` int(11) DEFAULT NULL,
  `statusG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateG` date DEFAULT NULL,
  `provisionG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_hausrat`
--

CREATE TABLE `costumer_status_hausrat` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idH` int(11) DEFAULT NULL,
  `societyH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kvg_premiumH` int(11) DEFAULT NULL,
  `statusH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateH` date DEFAULT NULL,
  `provisionH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_retchsschutz`
--

CREATE TABLE `costumer_status_retchsschutz` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idR` int(11) DEFAULT NULL,
  `productR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `durationR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statusR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateR` date DEFAULT NULL,
  `provisionR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_vorsorge`
--

CREATE TABLE `costumer_status_vorsorge` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idV` int(11) DEFAULT NULL,
  `societyV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productionV` int(11) DEFAULT NULL,
  `statusV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateV` date DEFAULT NULL,
  `provisionV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_zusatzversicherung`
--

CREATE TABLE `costumer_status_zusatzversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idZ` int(11) DEFAULT NULL,
  `societyZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vvg_premiumZ` int(11) DEFAULT NULL,
  `statusZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateZ` date DEFAULT NULL,
  `provisionZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deletedlead`
--

CREATE TABLE `deletedlead` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` int(11) NOT NULL,
  `date` date NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `family_person`
--

CREATE TABLE `family_person` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthdate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leads_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kundportfolio` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `family_person`
--

INSERT INTO `family_person` (`id`, `first_name`, `last_name`, `birthdate`, `leads_id`, `created_at`, `updated_at`, `status`, `status_updated_at`, `kundportfolio`) VALUES
(15, 'Myles ', 'Cathleen Jefferson', '1992-11-17', 13, '2022-02-18 11:12:33', '2022-02-24 07:54:47', 'Submited', '2022-02-18 12:12:33', 0),
(16, 'Sylvia ', 'Melyssa Perez', '2019-02-08', 13, '2022-02-18 11:12:33', '2022-02-21 11:24:14', 'Open', '2022-02-18 12:12:33', 0),
(17, 'Sasha', 'Honorato Daniel', '2013-08-02', 13, '2022-02-18 11:12:33', '2022-02-21 12:34:34', 'Open', '2022-02-18 12:12:33', 0),
(18, 'Nehru Blake', 'Laura Kim', '2001-01-07', 14, '2022-02-18 14:54:26', '2022-02-18 14:54:26', 'Submited', '2022-02-18 15:54:26', 0),
(19, 'Kali', 'Pela', '1992-11-17', 13, '2022-02-18 11:12:33', '2022-02-21 11:19:28', 'Open', '2022-02-18 12:12:33', 0),
(20, 'Florence Wilkins', 'Len Hart', '1972-07-14', 21, '2022-02-23 12:16:44', '2022-02-23 12:16:44', 'Open', '2022-02-23 13:16:44', 0);

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdate` date DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` int(11) DEFAULT NULL,
  `latitude` double(11,8) DEFAULT NULL,
  `longitude` double(11,8) DEFAULT NULL,
  `number_of_persons` int(11) DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_task` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_contract` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `appointment_date` date DEFAULT NULL,
  `campaign_id` int(11) NOT NULL DEFAULT '1',
  `assign_to_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned` tinyint(1) NOT NULL DEFAULT '0',
  `wantsonline` tinyint(1) NOT NULL DEFAULT '0',
  `rejected` tinyint(1) NOT NULL DEFAULT '0',
  `zufriedenheit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gesundheit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bemerkung` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sprache` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `berater` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `first_name`, `last_name`, `telephone`, `birthdate`, `city`, `address`, `postal_code`, `latitude`, `longitude`, `number_of_persons`, `nationality`, `slug`, `status_task`, `status_contract`, `completed`, `appointment_date`, `campaign_id`, `assign_to_id`, `created_at`, `updated_at`, `time`, `assigned`, `wantsonline`, `rejected`, `zufriedenheit`, `gesundheit`, `bemerkung`, `sprache`, `berater`, `agent`) VALUES
(1, 'Bulzart', 'Aliu', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'SPfXJPtVuirshNUS', NULL, NULL, 0, '2022-02-16', 3, 5, '2022-02-16 12:38:11', '2022-02-16 12:51:36', '15:00', 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Bajram', 'Aliu', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'YeoWufUvmpjtshJW', NULL, NULL, 0, NULL, 3, NULL, '2022-02-16 12:38:11', '2022-02-24 11:28:51', NULL, 0, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Enis', 'Demolli', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'QYRYejWNMCullWGc', NULL, NULL, 0, NULL, 1, 5, '2022-02-16 12:38:11', '2022-02-15 23:00:00', NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'albenit', 'Bytyqi', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'paAjwjtOQFhdKCzf', NULL, NULL, 0, NULL, 2, 5, '2022-02-16 12:38:11', '2022-02-23 23:00:00', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Jasin', 'Bilalli', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'SmUzZgOvkDQsbZfT', NULL, NULL, 0, NULL, 3, 5, '2022-02-16 12:38:11', '2022-02-23 23:00:00', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Art', 'Shabani', '045464926', '2000-02-09', NULL, 'Prishtine', NULL, NULL, NULL, 2, NULL, 'kZGYNPgCZNnuzJPM', NULL, NULL, 0, NULL, 2, NULL, '2022-02-16 12:38:11', '2022-02-16 12:38:11', NULL, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Flori', 'Frrokaj', '045464926', '2000-02-10', NULL, 'Prishtine', NULL, NULL, NULL, 1, NULL, 'xSkmTeVisWtokIcr', NULL, NULL, 0, NULL, 1, 5, '2022-02-16 12:38:11', '2022-02-23 23:00:00', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'Altin', 'Ahmetaj', '045464926', '2000-02-10', NULL, 'Prishtine', NULL, NULL, NULL, 2, NULL, 'TLEUAkElkUfojwLP', NULL, NULL, 0, NULL, 3, 5, '2022-02-16 12:38:11', '2022-02-23 23:00:00', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Bulzart', 'Aliu', '416780380', NULL, 'zasawqsw', '6078 zasawqsw', 6078, 0.00000000, 0.00000000, 2, 'Schweizer', NULL, NULL, NULL, 0, '2022-03-03', 1, 6, '2021-03-15 16:51:39', '2022-02-16 14:16:07', '14:45', 1, 0, 0, NULL, NULL, 'Ich habe mit dem Mann den Termin vereinbart \nEr ist für den vergleich offen .', 'Deutsch', 'Youcall16.03 (Das ist kein Termin und  gesundheitliche Frage nicht gut gestellt ) ', 'Meyer'),
(10, 'Test', 'Test', '416780380', NULL, 'zasawqsw', '6078 zasawqsw', 6078, 0.00000000, 0.00000000, 2, 'Schweizer', NULL, NULL, NULL, 0, '2022-03-03', 1, 5, '2021-03-15 16:51:39', '2022-02-16 13:52:23', '15:00', 1, 0, 0, NULL, NULL, 'Ich habe mit dem Mann den Termin vereinbart \nEr ist für den vergleich offen .', 'Deutsch', 'Youcall16.03 (Das ist kein Termin und  gesundheitliche Frage nicht gut gestellt ) ', 'Meyer'),
(11, 'Test', 'Test', '416780380', NULL, 'zasawqsw', '6078 zasawqsw', 6078, 0.00000000, 0.00000000, 2, 'Schweizer', NULL, NULL, NULL, 0, '2022-03-03', 1, 5, '2021-03-15 16:51:39', '2022-02-16 13:25:32', '15:00', 1, 0, 0, NULL, NULL, 'Ich habe mit dem Mann den Termin vereinbart \nEr ist für den vergleich offen .', 'Deutsch', 'Youcall16.03 (Das ist kein Termin und  gesundheitliche Frage nicht gut gestellt ) ', 'Meyer'),
(12, 'Kimberley Wood', 'Tanya Leach', 'Olga Acosta', NULL, 'Miranda WalterWesley Hyde', 'Kosovo', 94, 42.60263590, 20.90297700, 41, 'Galvin Houston', 'kimberley-wood-12', NULL, NULL, 0, '2022-02-18', 0, NULL, '2022-02-18 11:11:14', '2022-02-18 11:11:14', '16:00', 1, 1, 0, 'Charlotte Greene', NULL, 'Facere vel et volupt', 'Farrah Nolan', 'Katelyn Owen', 'Trevor Golden'),
(13, 'Gavin Dillard', 'Phoebe Mcguire', 'Oprah Richmond', NULL, 'Craig JacksonHarriet Bowen', 'Prishtine', 58, 42.66291380, 21.16550280, 3, 'Velma Silva', 'gavin-dillard-13', 'open', NULL, 1, '2022-02-18', 0, 5, '2022-02-18 11:12:09', '2022-02-18 11:12:33', '05:01', 1, 0, 0, 'Aline Clements', NULL, 'Nisi est nostrum qua', 'Farrah Mccormick', 'Harlan Barrera', 'Pamela Webb'),
(14, 'Dawn Powers', 'Brielle Peters', 'Timothy Gardner', NULL, 'Priscilla PatelNicholas Carver', 'Kosovo', 9, 42.60263590, 20.90297700, 16, 'Griffin Mayer', 'dawn-powers-14', 'open', NULL, 1, '2022-02-18', 0, 7, '2022-02-18 14:53:51', '2022-02-18 14:54:26', '03:38', 1, 0, 0, 'Ivory Mcfadden', NULL, 'Magni hic magni volu', 'Cara Sweeney', 'Deborah Knowles', 'Kessie Hester'),
(15, 'Dawn Powers', 'Brielle Peters', 'Timothy Gardner', NULL, 'Priscilla PatelNicholas Carver', 'Kosovo', 9, 42.60263590, 20.90297700, 16, 'Griffin Mayer', 'dawn-powers-15', NULL, NULL, 0, '2022-02-18', 0, 5, '2022-02-18 14:54:06', '2022-02-18 14:54:06', '03:38', 1, 0, 0, 'Ivory Mcfadden', NULL, 'Magni hic magni volu', 'Cara Sweeney', 'Deborah Knowles', 'Kessie Hester'),
(16, 'Oren Garrett', 'Jescie English', 'Alexis Waller', NULL, 'Yael PruittNoah Foley', 'Prishtine', 20, 0.00000000, 0.00000000, 35, 'Quyn Berger', NULL, NULL, NULL, 0, '2022-02-23', 0, 5, '2022-02-23 09:52:18', '2022-02-23 09:52:18', '09:26', 1, 0, 0, 'Wallace Hurley', NULL, 'Est est perferendis', 'Sharon Black', 'Zeus Wolf', 'Teagan Alston'),
(17, 'Ulla Norris', 'Debra French', 'Sophia Jennings', NULL, 'Xantha ParsonsUlysses Pollard', 'Prishtine', 73, 0.00000000, 0.00000000, 47, 'Colleen Morin', NULL, NULL, NULL, 0, '2004-03-13', 0, 5, '2022-02-23 11:05:56', '2022-02-23 11:05:56', '06:38', 1, 0, 0, 'Hanae Medina', NULL, 'Recusandae Laudanti', 'Vernon Ferrell', 'Selma Ray', 'Athena Raymond'),
(18, 'Quyn Norris', 'Yen Aguilar', 'Jade Owens', NULL, 'Kiona SheppardRonan Mcneil', 'Prishtine', 18, 0.00000000, 0.00000000, 12, 'Emerald Watson', NULL, NULL, NULL, 0, '1981-05-27', 0, 5, '2022-02-23 11:07:53', '2022-02-23 11:07:53', '06:10', 1, 0, 0, 'Arthur Maynard', NULL, 'Porro id ex quo in e', 'Ina Rutledge', 'Herman Wood', 'Sybil Vincent'),
(19, 'Maggy Carr', 'Cailin Jensen', 'Erica William', NULL, 'Conan HobbsLucas Castro', 'Prishtine', 51, 0.00000000, 0.00000000, 75, 'Breanna Porter', NULL, NULL, NULL, 0, '2022-02-23', 0, 6, '2022-02-23 11:09:05', '2022-02-23 11:09:05', '02:03', 1, 0, 0, 'Chastity Navarro', NULL, 'Aut et ipsam iste et', 'Michael Crane', 'Xavier Dixon', 'Knox Roth'),
(20, 'Idona Marshall', 'Madeline Moody', 'Lenore Patrick', NULL, 'Raphael BallIvory Perkins', 'Prishtine', 5, 0.00000000, 0.00000000, 71, 'Margaret Rios', NULL, NULL, NULL, 0, '1983-03-14', 0, 6, '2022-02-23 11:10:45', '2022-02-23 11:10:45', '16:26', 1, 0, 0, 'Martin Roach', NULL, 'Laudantium iusto at', 'Steven York', 'Rina Lester', 'Xaviera Bridges'),
(21, 'bulzart', 'bulzart', 'Lenore Patrick', NULL, 'Raphael BallIvory Perkins', 'Prishtine', 5, 0.00000000, 0.00000000, 71, 'Margaret Rios', 'bulzart-21', 'open', NULL, 1, '2022-03-03', 0, 5, '2022-02-23 11:15:42', '2022-02-23 12:16:44', '16:26', 1, 0, 0, 'Martin Roach', NULL, 'Laudantium iusto at', 'Steven York', 'Rina Lester', 'Xaviera Bridges'),
(22, 'test2', 'test2', 'Adria Wilkinson', NULL, 'Hasad PhelpsLeroy Harvey', 'Ferizaj', 6, 0.00000000, 0.00000000, 43, 'Finn Harvey', 'test2-22', NULL, NULL, 0, '2022-02-23', 0, 5, '2022-02-23 11:40:05', '2022-02-23 13:29:32', '16:13', 1, 0, 0, 'Cedric Hester', NULL, 'Repellendus Adipisi', 'Iris Miles', 'Keith Mcintosh', 'Aretha Mccoy'),
(23, 'Minerva Waters', 'Althea Simon', 'Hedley Mcgowan', NULL, 'Shaeleigh AyersGrady Mejia', 'kosove', 29, 0.00000000, 0.00000000, 42, 'Fiona Jackson', 'minerva-waters-23', NULL, NULL, 0, '2022-02-27', 0, 5, '2022-02-23 13:29:14', '2022-02-23 13:29:14', '09:00', 1, 0, 0, 'Xander Whitley', NULL, 'Atque veniam sint r', 'Josephine Gallegos', 'Isadora Martin', 'Merritt Erickson'),
(24, 'Buli Aliu', 'Aliu', 'Dustin Leonard', NULL, 'Summer MccoyKirestin Villarreal', 'Branden Stanton', 64, 0.00000000, 0.00000000, 44, 'Chloe Caldwell', 'buli-aliu-24', NULL, NULL, 0, '2022-02-24', 0, 6, '2022-02-23 14:08:19', '2022-02-24 09:35:07', '13:13', 1, 0, 0, 'Alika Colon', NULL, 'Cupidatat natus exce', 'Lesley Callahan', 'Kirsten Valdez', 'Preston Jacobs'),
(25, 'Aaaaaaaa', 'Bbbbbbbbb', 'Amethyst Tate', NULL, 'Zephania CareyStuart Hardy', 'Ramadan Ferizi', 20, 0.00000000, 0.00000000, 96, 'Jerome Bradley', 'aaaaaaaa-25', NULL, NULL, 0, '2022-02-23', 0, 5, '2022-02-23 14:37:27', '2022-02-23 14:37:40', '03:59', 1, 0, 0, 'Isabella Gregory', NULL, 'Aut placeat omnis n', 'Dai Floyd', 'Caleb Mosley', 'Wilma Phillips'),
(26, 'c', 'c', 'Damon Simmons', NULL, 'Cody GriffithUlric Benjamin', 'Doris Clark', 28, 0.00000000, 0.00000000, 83, 'Stuart Hess', 'c-26', NULL, NULL, 0, '2022-02-24', 0, 5, '2022-02-24 11:58:44', '2022-02-24 11:58:44', '19:11', 1, 0, 0, 'Kevyn Spears', NULL, 'Quia fuga Qui cupid', 'Brett Lowery', 'Suki Ingram', 'Nathaniel Deleon'),
(27, 'Bul', 'Buli', 'Kylie Lambert', NULL, 'Peter ConwayVenus Adkins', 'Kaitlin Cross', 55, 0.00000000, 0.00000000, 52, 'Dustin Bradshaw', 'bul-27', NULL, NULL, 0, '2022-02-25', 0, 8, '2022-02-24 12:00:12', '2022-02-24 12:00:32', '14:44', 1, 0, 0, 'Tyrone Kidd', NULL, 'Non id architecto p', 'Quinn Scott', 'Colton Horne', 'Lamar Nash'),
(28, 'Bulzart', 'Aliu', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'ZpMfzPHYeermalpo', NULL, NULL, 0, NULL, 3, NULL, '2022-02-24 15:05:30', '2022-02-24 15:05:30', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 'Bajram', 'Aliu', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'XNQHCyTnVnFwcSlH', NULL, NULL, 0, NULL, 3, NULL, '2022-02-24 15:05:30', '2022-02-24 15:05:30', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 'Enis', 'Demolli', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'vVNmPAGHWoUKZTIc', NULL, NULL, 0, '2022-02-25', 1, 5, '2022-02-24 15:05:30', '2022-02-24 15:07:26', '16:07', 1, 0, 0, NULL, NULL, NULL, NULL, 'fs1', 'fs1'),
(31, 'albenit', 'Bytyqi', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'NIkFwbdMMYToGBUg', NULL, NULL, 0, NULL, 2, NULL, '2022-02-24 15:05:30', '2022-02-24 15:05:30', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 'Jasin', 'Bilalli', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'wmtOixkdtUXPuYvX', NULL, NULL, 0, NULL, 3, NULL, '2022-02-24 15:05:30', '2022-02-24 15:05:30', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(33, 'Art', 'Shabani', '045464926', '2000-02-09', NULL, 'Prishtine', NULL, NULL, NULL, 2, NULL, 'BDVPxzwjArnAuitY', NULL, NULL, 0, NULL, 2, NULL, '2022-02-24 15:05:30', '2022-02-24 15:05:30', NULL, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(34, 'Flori', 'Frrokaj', '045464926', '2000-02-10', NULL, 'Prishtine', NULL, NULL, NULL, 1, NULL, 'tZHXisfwVTAnydKl', NULL, NULL, 0, NULL, 1, NULL, '2022-02-24 15:05:30', '2022-02-24 15:05:30', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 'Altin', 'Ahmetaj', '045464926', '2000-02-10', NULL, 'Prishtine', NULL, NULL, NULL, 2, NULL, 'YUWbVQAqUMIMJoJZ', NULL, NULL, 0, NULL, 3, NULL, '2022-02-24 15:05:30', '2022-02-24 15:05:30', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 'Gabriel Fisher', 'Tana Barrera', 'Alexis Evans', NULL, 'Wade OlsenAlana Glass', 'Jaime Rosa', 22, 0.00000000, 0.00000000, 80, 'Ivor Beach', 'gabriel-fisher-36', NULL, NULL, 0, '2022-02-27', 0, NULL, '2022-02-27 14:34:06', '2022-02-27 14:34:06', '09:00', 0, 0, 0, 'Quail Simpson', NULL, 'Eu ex consequuntur u', 'Noble Glenn', 'Illiana Ramirez', 'Gary Mcmillan');

-- --------------------------------------------------------

--
-- Table structure for table `leads_history`
--

CREATE TABLE `leads_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_a_counteroffered`
--

CREATE TABLE `lead_data_a_counteroffered` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `upload_police` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comparison_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_fahrzeug`
--

CREATE TABLE `lead_data_fahrzeug` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `upload_police` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leasing` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leasing_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_of_purchase` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placing_on_the_market` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance_date` date DEFAULT NULL,
  `redeemed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `km_stood` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issue_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `most_common` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deductible` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `carried` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_shop` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accident_coverage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `traffic_legal_protection` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grossly` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `glass_protection` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parking_damage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hour_breakdown_assistance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `first_intro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mandatiert` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_kk`
--

CREATE TABLE `lead_data_kk` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `pre_insurer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_required` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notice_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `power_of_attorney` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_s`
--

CREATE TABLE `lead_data_s` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `residence_permit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone_nr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zivilstand` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employment_relationship` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_frequency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_per_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `share_guarantee` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_of_contract` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `premium_exemption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eu_pension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `death_benefit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smoker` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desired` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nationality_sachen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_s_w`
--

CREATE TABLE `lead_data_s_w` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `upload_police` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comparison_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_of_people` int(11) DEFAULT NULL,
  `number_of_rooms` int(11) DEFAULT NULL,
  `sum_insured` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desired_additional_coverage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personal_liability` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `n_of_p_legal_protection` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_info`
--

CREATE TABLE `lead_info` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` int(11) NOT NULL,
  `krankenkasse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wichtig` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bewertung` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grund` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kampagne` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `teilnahme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_11_25_104229_costumers_table_migration', 1),
(6, '2021_11_25_122936_create_admins_table', 1),
(7, '2021_11_27_132304_create_leads_table', 1),
(8, '2021_11_27_142414_change_campaign_leads', 1),
(9, '2021_11_27_152057_add_unsigned_leads', 1),
(10, '2021_11_29_105505_add_completed_leads', 1),
(11, '2021_11_29_150416_add_address_leads', 1),
(12, '2021_11_30_105617_lead_add_fields', 1),
(13, '2021_11_30_151111_add_lead_online', 1),
(14, '2021_12_01_095352_create_chats_table', 1),
(15, '2021_12_01_153328_add_app_field', 1),
(16, '2021_12_04_113832_appointment_add_time', 1),
(17, '2021_12_04_132939_add_slug_leads', 1),
(18, '2021_12_06_144011_create_appointments_table', 1),
(19, '2021_12_07_133128_rejected_leads', 1),
(21, '2021_12_16_130603_deletedlead', 1),
(22, '2021_12_21_134427_add_assign_date', 1),
(23, '2021_12_21_143920_create_todos_table', 1),
(24, '2021_12_21_173622_create_tasks_table', 1),
(25, '2021_12_22_091851_add_table_trainings', 1),
(26, '2021_12_22_104145_add_latlong_csapp', 1),
(27, '2021_12_25_140442_add_duration_leads', 1),
(28, '2021_12_27_142212_create_admin_appointments_table', 1),
(29, '2021_12_27_143435_create_permission_tables', 1),
(30, '2021_12_27_171034_leads', 1),
(31, '2021_12_27_172337_family_person', 1),
(32, '2021_12_27_172634_lead_data_kk', 1),
(33, '2021_12_27_173014_lead_data_a_counteroffered', 1),
(34, '2021_12_27_173220_lead_data_s', 1),
(35, '2021_12_27_173824_lead_data_s_w', 1),
(37, '2021_12_28_155733_add_time_leads_as_appointment', 1),
(38, '2021_12_29_121151_add_status_family', 1),
(39, '2021_12_29_152931_create_campaign_table', 1),
(40, '2021_12_30_103848_add_accepted_status', 1),
(41, '2021_12_30_134129_add_status_time', 1),
(42, '2021_12_31_100929_add_time_trainings', 1),
(43, '2022_01_03_172744_add_pendencies_table', 1),
(44, '2022_01_07_095722_create_teams_table', 1),
(45, '2022_01_07_095957_create_team_consultants_table', 1),
(46, '2022_01_08_111143_create_chat_tables', 1),
(47, '2022_01_11_123245_test', 1),
(48, '2022_01_24_142241_personal_appointment_table', 1),
(49, '2022_01_25_151625_table_costumer_status_grundversicherung', 1),
(50, '2022_01_25_154921_table_costumer_status_zusatzversicherung', 1),
(51, '2022_01_25_155250_table_costumer_status_retchsschutz', 1),
(52, '2022_01_25_155642_table_costumer_status_hausrat', 1),
(53, '2022_01_25_155841_table_costumer_status_vorsorge', 1),
(54, '2022_01_26_135245_table_costumer_produkt_grundversicherung', 1),
(55, '2022_01_26_142438_table_costumer_produkt_zusatzversicherung', 1),
(56, '2022_01_26_145110_table_costumer_produkt_rechtsschutz', 1),
(57, '2022_01_26_145802_table_costumer_produkt_vorsorge', 1),
(58, '2022_01_27_084059_add_complete_costumer_form', 1),
(59, '2022_01_27_142916_leads_history', 1),
(60, '2022_01_29_154710_add_rejected_field', 1),
(61, '2022_01_31_091438_table_costumer_produkt_autoversicherung', 1),
(62, '2022_01_31_091525_table_costumer_produkt_hausrat', 1),
(63, '2022_02_01_112335_add_berater_leads', 2),
(64, '2022_02_03_130427_lead_info', 3),
(65, '2022_02_04_144000_add_comment_in_todos', 4),
(66, '2022_02_05_004731_add_pendency_id', 4),
(67, '2022_02_05_100724_add_agent_table_leads', 5),
(68, '2022_02_05_100724_add_agent_table_leads', 1),
(69, '2022_02_09_150454_add_date_at_personal_app', 6),
(74, '2022_02_12_121145_add_type_pendency', 8),
(75, '2022_02_12_102106_create_notifications_table', 9),
(79, '2022_02_14_124732_create_notifications_table', 10),
(84, '2022_02_19_153819_addanother_thing_n', 11),
(86, '2021_12_27_174239_lead_data_fahrzeug', 12),
(87, '2022_02_15_094109_add_mandatiert_field', 13);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\Admins', 2),
(2, 'App\\Models\\Admins', 3),
(3, 'App\\Models\\Admins', 4),
(7, 'App\\Models\\Admins', 5),
(7, 'App\\Models\\Admins', 6),
(7, 'App\\Models\\Admins', 7),
(7, 'App\\Models\\Admins', 8),
(6, 'App\\Models\\Admins', 9);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('71fb2e74-0525-4306-8624-594746f4c135', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 5, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6ImpEZjdQZ1pBdlQ0NEp6VHFkOFRmVkE9PSIsInZhbHVlIjoicUxIWWZHeHlRNkxmUUlIQ1k4OUoyZz09IiwibWFjIjoiNTFhYmRiZTIxNTZhZGJlYzE5NjJmZTM1NmI5ZTk5OWI0YThkNWJlYTEwODM5NWEwMWNjN2NiZjBmNjMxMmEwMSIsInRhZyI6IiJ9\\/eyJpdiI6InljbUh2Zk5iRVZqZjg5QXFWRWpEOFE9PSIsInZhbHVlIjoiUVM3YVk5Y1JXSmMzVit4d0RIY01uZz09IiwibWFjIjoiMmU1MzFlMGZjM2M5NTM1ODY5ZWUyZjQzOTc3NjVlNDE4YmJjNDNhYzhjMTZlN2EyZDZlNWI5YmE0MjFkNjgwZCIsInRhZyI6IiJ9?pend_id=1\\\"> You were asigned with a pendency for:Myles <\\/a>\"', '2022-02-25 15:04:03', '2022-02-25 11:21:12', '2022-02-25 15:04:03'),
('71fb2e74-0525-4306-8624-594746f4c13c', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 5, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6ImpEZjdQZ1pBdlQ0NEp6VHFkOFRmVkE9PSIsInZhbHVlIjoicUxIWWZHeHlRNkxmUUlIQ1k4OUoyZz09IiwibWFjIjoiNTFhYmRiZTIxNTZhZGJlYzE5NjJmZTM1NmI5ZTk5OWI0YThkNWJlYTEwODM5NWEwMWNjN2NiZjBmNjMxMmEwMSIsInRhZyI6IiJ9\\/eyJpdiI6InljbUh2Zk5iRVZqZjg5QXFWRWpEOFE9PSIsInZhbHVlIjoiUVM3YVk5Y1JXSmMzVit4d0RIY01uZz09IiwibWFjIjoiMmU1MzFlMGZjM2M5NTM1ODY5ZWUyZjQzOTc3NjVlNDE4YmJjNDNhYzhjMTZlN2EyZDZlNWI5YmE0MjFkNjgwZCIsInRhZyI6IiJ9?pend_id=1\\\"> You were asigned with a zhzha for:Myxes <\\/a>\"', '2022-02-25 15:04:03', '2022-02-25 11:21:12', '2022-02-25 15:04:03');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pendencies`
--

CREATE TABLE `pendencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `family_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pendencies`
--

INSERT INTO `pendencies` (`id`, `admin_id`, `family_id`, `description`, `done`, `completed`, `created_at`, `updated_at`, `title`, `type`) VALUES
(1, 5, 15, '', 0, 0, '2022-02-25 11:21:12', '2022-02-25 11:21:12', '', 'task');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personalappointment`
--

CREATE TABLE `personalappointment` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` time NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `AppOrCon` int(11) NOT NULL,
  `assignfrom` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personalappointment`
--

INSERT INTO `personalappointment` (`id`, `title`, `time`, `address`, `comment`, `user_id`, `AppOrCon`, `assignfrom`, `created_at`, `updated_at`, `date`) VALUES
(1, 'Sot meeting', '14:13:00', 'Kosove', 'Test', 5, 1, 2, '2022-02-09 09:13:35', '2022-02-09 09:13:35', '2022-02-11'),
(2, 'Konsultim', '08:20:00', 'Ferizaj', 'aaaaaaaaaaaaaaa', 2, 1, 4, '2022-02-10 09:12:40', '2022-02-10 09:12:40', '2022-02-10'),
(3, 'Dicta et tempore cu', '17:33:00', 'Dolor facere aliquam', 'Cupidatat ut dolorum', 2, 1, 2, '2022-02-10 09:13:14', '2022-02-10 09:13:14', '2022-02-10'),
(4, 'Albeniti', '04:35:00', 'Proident esse bland', 'Modi consequuntur ex', 2, 1, 2, '2022-02-11 08:57:53', '2022-02-11 08:57:53', '2003-10-29'),
(5, 'Takimi per Dokumenta', '14:46:00', 'Nzyre', 'Si ke Kry do sene bre burr', 5, 1, 2, '2022-02-11 09:36:45', '2022-02-11 09:36:45', '2022-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rejectedleads`
--

CREATE TABLE `rejectedleads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(2, 'backoffice', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(3, 'salesmanager', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(4, 'management', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(5, 'finance', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(6, 'digital', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(7, 'fs', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_manager_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_consultants`
--

CREATE TABLE `team_consultants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` int(11) NOT NULL,
  `consultant_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE `todos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendency_id` bigint(20) DEFAULT NULL,
  `costumer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `todos`
--

INSERT INTO `todos` (`id`, `admin_id`, `pendency_id`, `costumer`, `text`, `comment`, `number`, `done`, `created_at`, `updated_at`) VALUES
(1, '3', NULL, NULL, '123', NULL, '1', 0, '2022-02-09 07:34:22', '2022-02-09 07:34:22'),
(2, '3', NULL, NULL, '4444444', NULL, '1', 0, '2022-02-18 11:06:55', '2022-02-18 11:06:55');

-- --------------------------------------------------------

--
-- Table structure for table `trainings`
--

CREATE TABLE `trainings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` bigint(20) UNSIGNED DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin` bigint(20) DEFAULT NULL,
  `confirmed` tinyint(1) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addanother_thing_n`
--
ALTER TABLE `addanother_thing_n`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_another_item_g`
--
ALTER TABLE `add_another_item_g`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `admin_appointments`
--
ALTER TABLE `admin_appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chats_costumer_id_index` (`costumer_id`),
  ADD KEY `chats_admin_id_index` (`admin_id`),
  ADD KEY `chats_rating_index` (`rating`);

--
-- Indexes for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_messages_participation_id_foreign` (`participation_id`),
  ADD KEY `chat_messages_conversation_id_foreign` (`conversation_id`);

--
-- Indexes for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `participation_message_index` (`participation_id`,`message_id`),
  ADD KEY `chat_message_notifications_message_id_foreign` (`message_id`),
  ADD KEY `chat_message_notifications_conversation_id_foreign` (`conversation_id`);

--
-- Indexes for table `chat_participation`
--
ALTER TABLE `chat_participation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `participation_index` (`conversation_id`,`messageable_id`,`messageable_type`);

--
-- Indexes for table `costumers`
--
ALTER TABLE `costumers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `costumers_name_index` (`name`),
  ADD KEY `costumers_surname_index` (`surname`),
  ADD KEY `costumers_email_index` (`email`),
  ADD KEY `costumers_dateofbirth_index` (`dateofbirth`),
  ADD KEY `costumers_phone_index` (`phone`),
  ADD KEY `costumers_health_index` (`health`);

--
-- Indexes for table `costumer_podukt_zusatzversicherung`
--
ALTER TABLE `costumer_podukt_zusatzversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_autoversicherung`
--
ALTER TABLE `costumer_produkt_autoversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_grundversicherung`
--
ALTER TABLE `costumer_produkt_grundversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_hausrat`
--
ALTER TABLE `costumer_produkt_hausrat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_rechtsschutz`
--
ALTER TABLE `costumer_produkt_rechtsschutz`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_vorsorge`
--
ALTER TABLE `costumer_produkt_vorsorge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_grundversicherung`
--
ALTER TABLE `costumer_status_grundversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_hausrat`
--
ALTER TABLE `costumer_status_hausrat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_retchsschutz`
--
ALTER TABLE `costumer_status_retchsschutz`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_vorsorge`
--
ALTER TABLE `costumer_status_vorsorge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_zusatzversicherung`
--
ALTER TABLE `costumer_status_zusatzversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deletedlead`
--
ALTER TABLE `deletedlead`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `family_person`
--
ALTER TABLE `family_person`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads_history`
--
ALTER TABLE `leads_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_a_counteroffered`
--
ALTER TABLE `lead_data_a_counteroffered`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_fahrzeug`
--
ALTER TABLE `lead_data_fahrzeug`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_kk`
--
ALTER TABLE `lead_data_kk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_s`
--
ALTER TABLE `lead_data_s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_s_w`
--
ALTER TABLE `lead_data_s_w`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_info`
--
ALTER TABLE `lead_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `pendencies`
--
ALTER TABLE `pendencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personalappointment`
--
ALTER TABLE `personalappointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `rejectedleads`
--
ALTER TABLE `rejectedleads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_consultants`
--
ALTER TABLE `team_consultants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `todos`
--
ALTER TABLE `todos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trainings`
--
ALTER TABLE `trainings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addanother_thing_n`
--
ALTER TABLE `addanother_thing_n`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `add_another_item_g`
--
ALTER TABLE `add_another_item_g`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `admin_appointments`
--
ALTER TABLE `admin_appointments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaigns`
--
ALTER TABLE `campaigns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `chat_participation`
--
ALTER TABLE `chat_participation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT for table `costumers`
--
ALTER TABLE `costumers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_podukt_zusatzversicherung`
--
ALTER TABLE `costumer_podukt_zusatzversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_produkt_autoversicherung`
--
ALTER TABLE `costumer_produkt_autoversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_produkt_grundversicherung`
--
ALTER TABLE `costumer_produkt_grundversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_produkt_hausrat`
--
ALTER TABLE `costumer_produkt_hausrat`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_produkt_rechtsschutz`
--
ALTER TABLE `costumer_produkt_rechtsschutz`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_produkt_vorsorge`
--
ALTER TABLE `costumer_produkt_vorsorge`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_status_grundversicherung`
--
ALTER TABLE `costumer_status_grundversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_status_hausrat`
--
ALTER TABLE `costumer_status_hausrat`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_status_retchsschutz`
--
ALTER TABLE `costumer_status_retchsschutz`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_status_vorsorge`
--
ALTER TABLE `costumer_status_vorsorge`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_status_zusatzversicherung`
--
ALTER TABLE `costumer_status_zusatzversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deletedlead`
--
ALTER TABLE `deletedlead`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `family_person`
--
ALTER TABLE `family_person`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `leads_history`
--
ALTER TABLE `leads_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_data_a_counteroffered`
--
ALTER TABLE `lead_data_a_counteroffered`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_data_fahrzeug`
--
ALTER TABLE `lead_data_fahrzeug`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_data_kk`
--
ALTER TABLE `lead_data_kk`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_data_s`
--
ALTER TABLE `lead_data_s`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_data_s_w`
--
ALTER TABLE `lead_data_s_w`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_info`
--
ALTER TABLE `lead_info`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `pendencies`
--
ALTER TABLE `pendencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personalappointment`
--
ALTER TABLE `personalappointment`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rejectedleads`
--
ALTER TABLE `rejectedleads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `team_consultants`
--
ALTER TABLE `team_consultants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `todos`
--
ALTER TABLE `todos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trainings`
--
ALTER TABLE `trainings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_messages_participation_id_foreign` FOREIGN KEY (`participation_id`) REFERENCES `chat_participation` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  ADD CONSTRAINT `chat_message_notifications_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_message_notifications_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_message_notifications_participation_id_foreign` FOREIGN KEY (`participation_id`) REFERENCES `chat_participation` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_participation`
--
ALTER TABLE `chat_participation`
  ADD CONSTRAINT `chat_participation_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
