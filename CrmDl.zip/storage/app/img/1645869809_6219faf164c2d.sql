-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 18, 2022 at 04:21 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_another_item_g`
--

CREATE TABLE `add_another_item_g` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `upload_policeFahrzeug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comparison_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commentFahrenzug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `person_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `add_another_item_g`
--

INSERT INTO `add_another_item_g` (`id`, `upload_policeFahrzeug`, `comparison_type`, `commentFahrenzug`, `person_id`, `created_at`, `updated_at`) VALUES
(1, '1645198789_620fbdc50fabc.env', 'Select1', '1asd', 17, '2022-02-18 13:32:08', '2022-02-18 14:43:06'),
(2, '1645199096_620fbef8d9dd0.gitattributes', 'Select1', NULL, 16, '2022-02-18 14:44:56', '2022-02-18 14:44:56'),
(3, '1645199096_620fbef8dadcc.gitignore', 'Select2', NULL, 16, '2022-02-18 14:44:56', '2022-02-18 14:44:56');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonenumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pin` int(11) NOT NULL DEFAULT '0',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `online` tinyint(1) NOT NULL DEFAULT '0',
  `firsttime` tinyint(1) NOT NULL DEFAULT '1',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `phonenumber`, `pin`, `confirmed`, `online`, `firsttime`, `email_verified_at`, `password`, `created_at`, `updated_at`, `remember_token`) VALUES
(1, 'Nina', 'nina@gmail.com', NULL, 0, 0, 0, 1, NULL, '$2y$10$mgAbOs6.vPTQsnnbg05lYuSl816T.z.zY.Fc0XVwZwgH3zwwUJwJm', '2022-01-31 15:04:24', '2022-01-31 15:04:24', NULL),
(2, 'Albenit', 'admin@gmail.com', NULL, 9531, 0, 0, 1, NULL, '$2y$10$92Uvb9Lmf83jVHSK0HZ6Q.VcQHYt0ag8QMWtEQc9pd09ijCRXKELG', '2022-01-31 15:04:25', '2022-02-18 11:44:04', NULL),
(3, 'backoffice', 'backoffice@gmail.com', NULL, 5858, 0, 0, 1, NULL, '$2y$10$YqrCctcPkIiiWYQ6Lm/6L.GLvGQ6jhUGl/Q.8zy3q6SaBzQc2sFP6', '2022-01-31 15:04:25', '2022-02-18 15:06:29', NULL),
(4, 'salesmanager', 'salesmanager@gmail.com', NULL, 1120, 0, 0, 1, NULL, '$2y$10$4e/Q7oM1hRb.C4b5syXXYO97M1fATQypKA3W6kwJO1HPCKCt1pgbK', '2022-01-31 15:04:25', '2022-02-16 15:24:56', NULL),
(5, 'fs1', 'fs1@gmail.com', NULL, 9577, 0, 0, 1, NULL, '$2y$10$jddxlLCtzzRrHaMoE3s.GurKyPldEfy57y1LDV38f1m0Q5lwyUquG', '2022-01-31 15:04:25', '2022-02-18 11:33:05', NULL),
(6, 'fs2', 'fs2@gmail.com', NULL, 4611, 0, 0, 1, NULL, '$2y$10$mQnoxCpWHsg1nPTHGCRP2utk4v7ezqCoLeDxdy2VrYHUvVwB32Zw6', '2022-01-31 15:04:25', '2022-02-16 12:24:30', NULL),
(7, 'fs3', 'fs3@gmail.com', NULL, 6459, 0, 0, 1, NULL, '$2y$10$RKB5P7HOuoMY/mW.x..0B.U8GW7icth0LiyaBz84lhWYU7Qwa3Wri', '2022-01-31 15:04:25', '2022-02-09 08:15:01', NULL),
(8, 'fs4', 'fs4@gmail.com', NULL, 1474, 0, 0, 1, NULL, '$2y$10$LWeC6XrCI3HnTJpyFVP39OMfJuRQ6rYrDa28RCl1tk43I07efraq.', '2022-01-31 15:04:25', '2022-02-12 12:15:43', NULL),
(9, 'digital', 'digital@gmail.com', NULL, 7186, 0, 0, 1, NULL, '$2y$10$lTbQZzdmZsxbzsde3RoZj.lvvmV.F9jmsCIg8J4kMy/cmJCxEI9NG', '2022-01-31 15:04:25', '2022-02-05 08:08:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_appointments`
--

CREATE TABLE `admin_appointments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `family` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--

CREATE TABLE `campaigns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaigns`
--

INSERT INTO `campaigns` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'instagram', '2022-01-31 15:04:25', '2022-01-31 15:04:25'),
(2, 'facebook', '2022-01-31 15:04:25', '2022-01-31 15:04:25'),
(3, 'sanascout', '2022-01-31 15:04:25', '2022-01-31 15:04:25');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `costumer_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `chat` json DEFAULT NULL,
  `rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_conversations`
--

CREATE TABLE `chat_conversations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `private` tinyint(1) NOT NULL DEFAULT '1',
  `direct_message` tinyint(1) NOT NULL DEFAULT '0',
  `data` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_conversations`
--

INSERT INTO `chat_conversations` (`id`, `private`, `direct_message`, `data`, `created_at`, `updated_at`) VALUES
(1, 1, 0, '[]', '2022-02-04 17:12:24', '2022-02-04 17:12:24'),
(2, 1, 0, '[]', '2022-02-04 17:13:30', '2022-02-04 17:13:30'),
(3, 1, 0, '[]', '2022-02-04 17:16:48', '2022-02-04 17:16:48'),
(4, 1, 0, '[]', '2022-02-08 11:33:09', '2022-02-08 11:33:09'),
(5, 1, 0, '[]', '2022-02-14 07:20:39', '2022-02-14 07:20:39'),
(6, 1, 0, '[]', '2022-02-14 13:53:40', '2022-02-14 13:53:40'),
(7, 1, 0, '[]', '2022-02-14 14:40:17', '2022-02-14 14:40:17'),
(8, 1, 0, '[]', '2022-02-14 14:41:20', '2022-02-14 14:41:20'),
(9, 1, 0, '[]', '2022-02-16 11:41:54', '2022-02-16 11:41:54'),
(10, 1, 0, '[]', '2022-02-16 11:47:19', '2022-02-16 11:47:19'),
(11, 1, 0, '[]', '2022-02-16 11:47:37', '2022-02-16 11:47:37'),
(12, 1, 0, '[]', '2022-02-16 11:47:39', '2022-02-16 11:47:39'),
(13, 1, 0, '[]', '2022-02-16 11:49:50', '2022-02-16 11:49:50'),
(14, 1, 0, '[]', '2022-02-16 11:50:14', '2022-02-16 11:50:14'),
(15, 1, 0, '[]', '2022-02-16 11:50:16', '2022-02-16 11:50:16'),
(16, 1, 0, '[]', '2022-02-16 11:50:17', '2022-02-16 11:50:17'),
(17, 1, 0, '[]', '2022-02-16 11:50:37', '2022-02-16 11:50:37'),
(18, 1, 0, '[]', '2022-02-16 11:51:34', '2022-02-16 11:51:34'),
(19, 1, 0, '[]', '2022-02-16 11:51:45', '2022-02-16 11:51:45'),
(20, 1, 0, '[]', '2022-02-16 11:52:18', '2022-02-16 11:52:18'),
(21, 1, 0, '[]', '2022-02-16 11:52:26', '2022-02-16 11:52:26'),
(22, 1, 0, '[]', '2022-02-16 11:54:35', '2022-02-16 11:54:35'),
(23, 1, 0, '[]', '2022-02-16 11:55:33', '2022-02-16 11:55:33'),
(24, 1, 0, '[]', '2022-02-16 11:56:13', '2022-02-16 11:56:13'),
(25, 1, 0, '[]', '2022-02-16 11:56:52', '2022-02-16 11:56:52'),
(26, 1, 0, '[]', '2022-02-16 11:56:54', '2022-02-16 11:56:54'),
(27, 1, 0, '[]', '2022-02-16 11:56:56', '2022-02-16 11:56:56'),
(28, 1, 0, '[]', '2022-02-16 11:57:01', '2022-02-16 11:57:01'),
(29, 1, 0, '[]', '2022-02-16 11:57:06', '2022-02-16 11:57:06'),
(30, 1, 0, '[]', '2022-02-16 11:57:20', '2022-02-16 11:57:20'),
(31, 1, 0, '[]', '2022-02-16 11:58:13', '2022-02-16 11:58:13'),
(32, 1, 0, '[]', '2022-02-16 11:58:14', '2022-02-16 11:58:14'),
(33, 1, 0, '[]', '2022-02-16 12:02:32', '2022-02-16 12:02:32'),
(34, 1, 0, '[]', '2022-02-16 12:03:01', '2022-02-16 12:03:01'),
(35, 1, 0, '[]', '2022-02-16 12:03:03', '2022-02-16 12:03:03'),
(36, 1, 1, '[]', '2022-02-16 12:03:06', '2022-02-16 12:08:04');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `participation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `body`, `conversation_id`, `participation_id`, `type`, `created_at`, `updated_at`) VALUES
(1, 'bulzart', 36, 72, 'file', '2022-02-16 12:03:06', '2022-02-16 12:03:06'),
(2, '1645016658_620cf652c249e.txt', 36, 72, 'file', '2022-02-16 12:04:18', '2022-02-16 12:04:18'),
(3, 'aaa', 36, 72, 'text', '2022-02-16 12:07:45', '2022-02-16 12:07:45'),
(4, '1645016876_620cf72c6c3ec.json', 36, 72, 'file', '2022-02-16 12:07:56', '2022-02-16 12:07:56'),
(5, 'so file', 36, 72, 'text', '2022-02-16 12:08:04', '2022-02-16 12:08:04');

-- --------------------------------------------------------

--
-- Table structure for table `chat_message_notifications`
--

CREATE TABLE `chat_message_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `message_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `participation_id` bigint(20) UNSIGNED NOT NULL,
  `is_seen` tinyint(1) NOT NULL DEFAULT '0',
  `is_sender` tinyint(1) NOT NULL DEFAULT '0',
  `flagged` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_message_notifications`
--

INSERT INTO `chat_message_notifications` (`id`, `message_id`, `messageable_id`, `messageable_type`, `conversation_id`, `participation_id`, `is_seen`, `is_sender`, `flagged`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:03:06', NULL, NULL),
(2, 1, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:03:06', NULL, NULL),
(3, 2, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:04:18', NULL, NULL),
(4, 2, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:04:18', NULL, NULL),
(5, 3, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:07:45', NULL, NULL),
(6, 3, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:07:45', NULL, NULL),
(7, 4, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:07:56', NULL, NULL),
(8, 4, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:07:56', NULL, NULL),
(9, 5, 3, 'App\\Models\\Admins', 36, 72, 1, 1, 0, '2022-02-16 12:08:04', NULL, NULL),
(10, 5, 5, 'App\\Models\\Admins', 36, 71, 0, 0, 0, '2022-02-16 12:08:04', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chat_participation`
--

CREATE TABLE `chat_participation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_id` bigint(20) UNSIGNED NOT NULL,
  `messageable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_participation`
--

INSERT INTO `chat_participation` (`id`, `conversation_id`, `messageable_id`, `messageable_type`, `settings`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 'App\\Models\\Admins', NULL, '2022-02-04 17:12:24', '2022-02-04 17:12:24'),
(2, 1, 3, 'App\\Models\\Admins', NULL, '2022-02-04 17:12:24', '2022-02-04 17:12:24'),
(3, 2, 5, 'App\\Models\\Admins', NULL, '2022-02-04 17:13:30', '2022-02-04 17:13:30'),
(4, 2, 3, 'App\\Models\\Admins', NULL, '2022-02-04 17:13:30', '2022-02-04 17:13:30'),
(5, 3, 5, 'App\\Models\\Admins', NULL, '2022-02-04 17:16:48', '2022-02-04 17:16:48'),
(6, 3, 3, 'App\\Models\\Admins', NULL, '2022-02-04 17:16:48', '2022-02-04 17:16:48'),
(7, 4, 6, 'App\\Models\\Admins', NULL, '2022-02-08 11:33:09', '2022-02-08 11:33:09'),
(8, 4, 3, 'App\\Models\\Admins', NULL, '2022-02-08 11:33:09', '2022-02-08 11:33:09'),
(9, 5, 5, 'App\\Models\\Admins', NULL, '2022-02-14 07:20:39', '2022-02-14 07:20:39'),
(10, 5, 3, 'App\\Models\\Admins', NULL, '2022-02-14 07:20:39', '2022-02-14 07:20:39'),
(11, 6, 5, 'App\\Models\\Admins', NULL, '2022-02-14 13:53:40', '2022-02-14 13:53:40'),
(12, 6, 3, 'App\\Models\\Admins', NULL, '2022-02-14 13:53:40', '2022-02-14 13:53:40'),
(13, 7, 5, 'App\\Models\\Admins', NULL, '2022-02-14 14:40:17', '2022-02-14 14:40:17'),
(14, 7, 3, 'App\\Models\\Admins', NULL, '2022-02-14 14:40:17', '2022-02-14 14:40:17'),
(15, 8, 5, 'App\\Models\\Admins', NULL, '2022-02-14 14:41:20', '2022-02-14 14:41:20'),
(16, 8, 3, 'App\\Models\\Admins', NULL, '2022-02-14 14:41:20', '2022-02-14 14:41:20'),
(17, 9, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:41:54', '2022-02-16 11:41:54'),
(18, 9, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:41:54', '2022-02-16 11:41:54'),
(19, 10, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:19', '2022-02-16 11:47:19'),
(20, 10, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:19', '2022-02-16 11:47:19'),
(21, 11, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:37', '2022-02-16 11:47:37'),
(22, 11, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:37', '2022-02-16 11:47:37'),
(23, 12, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:39', '2022-02-16 11:47:39'),
(24, 12, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:47:39', '2022-02-16 11:47:39'),
(25, 13, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:49:50', '2022-02-16 11:49:50'),
(26, 13, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:49:50', '2022-02-16 11:49:50'),
(27, 14, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:14', '2022-02-16 11:50:14'),
(28, 14, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:14', '2022-02-16 11:50:14'),
(29, 15, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:16', '2022-02-16 11:50:16'),
(30, 15, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:16', '2022-02-16 11:50:16'),
(31, 16, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:17', '2022-02-16 11:50:17'),
(32, 16, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:17', '2022-02-16 11:50:17'),
(33, 17, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:37', '2022-02-16 11:50:37'),
(34, 17, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:50:37', '2022-02-16 11:50:37'),
(35, 18, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:51:34', '2022-02-16 11:51:34'),
(36, 18, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:51:34', '2022-02-16 11:51:34'),
(37, 19, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:51:45', '2022-02-16 11:51:45'),
(38, 19, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:51:45', '2022-02-16 11:51:45'),
(39, 20, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:52:18', '2022-02-16 11:52:18'),
(40, 20, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:52:18', '2022-02-16 11:52:18'),
(41, 21, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:52:26', '2022-02-16 11:52:26'),
(42, 21, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:52:26', '2022-02-16 11:52:26'),
(43, 22, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:54:35', '2022-02-16 11:54:35'),
(44, 22, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:54:35', '2022-02-16 11:54:35'),
(45, 23, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:55:33', '2022-02-16 11:55:33'),
(46, 23, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:55:33', '2022-02-16 11:55:33'),
(47, 24, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:13', '2022-02-16 11:56:13'),
(48, 24, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:13', '2022-02-16 11:56:13'),
(49, 25, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:52', '2022-02-16 11:56:52'),
(50, 25, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:52', '2022-02-16 11:56:52'),
(51, 26, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:54', '2022-02-16 11:56:54'),
(52, 26, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:54', '2022-02-16 11:56:54'),
(53, 27, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:56', '2022-02-16 11:56:56'),
(54, 27, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:56:56', '2022-02-16 11:56:56'),
(55, 28, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:01', '2022-02-16 11:57:01'),
(56, 28, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:01', '2022-02-16 11:57:01'),
(57, 29, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:06', '2022-02-16 11:57:06'),
(58, 29, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:06', '2022-02-16 11:57:06'),
(59, 30, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:20', '2022-02-16 11:57:20'),
(60, 30, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:57:20', '2022-02-16 11:57:20'),
(61, 31, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:58:13', '2022-02-16 11:58:13'),
(62, 31, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:58:13', '2022-02-16 11:58:13'),
(63, 32, 5, 'App\\Models\\Admins', NULL, '2022-02-16 11:58:14', '2022-02-16 11:58:14'),
(64, 32, 3, 'App\\Models\\Admins', NULL, '2022-02-16 11:58:14', '2022-02-16 11:58:14'),
(65, 33, 5, 'App\\Models\\Admins', NULL, '2022-02-16 12:02:32', '2022-02-16 12:02:32'),
(66, 33, 3, 'App\\Models\\Admins', NULL, '2022-02-16 12:02:32', '2022-02-16 12:02:32'),
(67, 34, 5, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:01', '2022-02-16 12:03:01'),
(68, 34, 3, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:01', '2022-02-16 12:03:01'),
(69, 35, 5, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:03', '2022-02-16 12:03:03'),
(70, 35, 3, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:03', '2022-02-16 12:03:03'),
(71, 36, 5, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:06', '2022-02-16 12:03:06'),
(72, 36, 3, 'App\\Models\\Admins', NULL, '2022-02-16 12:03:06', '2022-02-16 12:03:06');

-- --------------------------------------------------------

--
-- Table structure for table `costumers`
--

CREATE TABLE `costumers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateofbirth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `mandated` tinyint(1) DEFAULT NULL,
  `actions` json NOT NULL,
  `birthday` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `civilstatus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kvg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vvg` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `health` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `costumer_podukt_zusatzversicherung`
--

CREATE TABLE `costumer_podukt_zusatzversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PZ` int(11) DEFAULT NULL,
  `graduation_date_PZ` date DEFAULT NULL,
  `society_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produkt_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vvg_premium_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_from_PZ` date DEFAULT NULL,
  `duration_to_PZ` date DEFAULT NULL,
  `status_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PZ` date DEFAULT NULL,
  `provision_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produkt_PZ2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vvg_premium_PZ2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_from_PZ2` date DEFAULT NULL,
  `duration_to_PZ2` date DEFAULT NULL,
  `status_PZ2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PZ2` date DEFAULT NULL,
  `provision_PZ2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_commisions_PZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_podukt_zusatzversicherung`
--

INSERT INTO `costumer_podukt_zusatzversicherung` (`id`, `person_id_PZ`, `graduation_date_PZ`, `society_PZ`, `produkt_PZ`, `vvg_premium_PZ`, `duration_from_PZ`, `duration_to_PZ`, `status_PZ`, `last_adjustment_PZ`, `provision_PZ`, `produkt_PZ2`, `vvg_premium_PZ2`, `duration_from_PZ2`, `duration_to_PZ2`, `status_PZ2`, `last_adjustment_PZ2`, `provision_PZ2`, `total_commisions_PZ`, `selected`, `created_at`, `updated_at`) VALUES
(1, 6, NULL, NULL, NULL, NULL, NULL, NULL, 'Abgelehnt', NULL, NULL, NULL, NULL, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(2, 15, NULL, NULL, NULL, NULL, NULL, NULL, 'notselected', NULL, NULL, NULL, NULL, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_autoversicherung`
--

CREATE TABLE `costumer_produkt_autoversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PA` int(11) DEFAULT NULL,
  `society_PA` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `beginning_insurance_PA` date DEFAULT NULL,
  `insurance_PA` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PA` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PA` date DEFAULT NULL,
  `total_commisions_PA` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_produkt_autoversicherung`
--

INSERT INTO `costumer_produkt_autoversicherung` (`id`, `person_id_PA`, `society_PA`, `beginning_insurance_PA`, `insurance_PA`, `status_PA`, `last_adjustment_PA`, `total_commisions_PA`, `selected`, `created_at`, `updated_at`) VALUES
(1, 6, NULL, NULL, NULL, 'Zuruckgezogen', NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(2, 15, NULL, NULL, NULL, 'notselected', NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_grundversicherung`
--

CREATE TABLE `costumer_produkt_grundversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PG` int(11) DEFAULT NULL,
  `graduation_date_PG` date DEFAULT NULL,
  `society_PG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_PG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PG` date DEFAULT NULL,
  `total_commisions_PG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_produkt_grundversicherung`
--

INSERT INTO `costumer_produkt_grundversicherung` (`id`, `person_id_PG`, `graduation_date_PG`, `society_PG`, `product_PG`, `status_PG`, `last_adjustment_PG`, `total_commisions_PG`, `selected`, `created_at`, `updated_at`) VALUES
(1, 6, NULL, NULL, NULL, 'Provisionert', NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(2, 15, NULL, NULL, NULL, 'Provisionert', NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_hausrat`
--

CREATE TABLE `costumer_produkt_hausrat` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PH` int(11) DEFAULT NULL,
  `society_PH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `beginning_insurance_PH` date DEFAULT NULL,
  `insurance_PH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PH` date DEFAULT NULL,
  `total_commisions_PH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_produkt_hausrat`
--

INSERT INTO `costumer_produkt_hausrat` (`id`, `person_id_PH`, `society_PH`, `beginning_insurance_PH`, `insurance_PH`, `status_PH`, `last_adjustment_PH`, `total_commisions_PH`, `selected`, `created_at`, `updated_at`) VALUES
(1, 6, NULL, NULL, NULL, 'Offen', NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(2, 15, NULL, NULL, NULL, 'notselected', NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_rechtsschutz`
--

CREATE TABLE `costumer_produkt_rechtsschutz` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PR` int(11) DEFAULT NULL,
  `graduation_date_PR` date DEFAULT NULL,
  `society_PR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produkt_PR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PR` date DEFAULT NULL,
  `total_commisions_PR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_produkt_rechtsschutz`
--

INSERT INTO `costumer_produkt_rechtsschutz` (`id`, `person_id_PR`, `graduation_date_PR`, `society_PR`, `produkt_PR`, `status_PR`, `last_adjustment_PR`, `total_commisions_PR`, `selected`, `created_at`, `updated_at`) VALUES
(1, 6, NULL, NULL, NULL, 'Provisionert', NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(2, 15, NULL, NULL, NULL, 'notselected', NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_produkt_vorsorge`
--

CREATE TABLE `costumer_produkt_vorsorge` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id_PV` int(11) DEFAULT NULL,
  `graduation_date_PV` date DEFAULT NULL,
  `begin_PV` date DEFAULT NULL,
  `society_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pramie_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_rythm_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_from_PV` date DEFAULT NULL,
  `duration_to_PV` date DEFAULT NULL,
  `production_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_adjustment_PV` date DEFAULT NULL,
  `total_commisions_PV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_produkt_vorsorge`
--

INSERT INTO `costumer_produkt_vorsorge` (`id`, `person_id_PV`, `graduation_date_PV`, `begin_PV`, `society_PV`, `pramie_PV`, `payment_rythm_PV`, `duration_from_PV`, `duration_to_PV`, `production_PV`, `status_PV`, `last_adjustment_PV`, `total_commisions_PV`, `selected`, `created_at`, `updated_at`) VALUES
(1, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'notselected', NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(2, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'notselected', NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_grundversicherung`
--

CREATE TABLE `costumer_status_grundversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idG` int(11) DEFAULT NULL,
  `societyG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kvg_premiumG` int(11) DEFAULT NULL,
  `statusG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateG` date DEFAULT NULL,
  `provisionG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidG` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_status_grundversicherung`
--

INSERT INTO `costumer_status_grundversicherung` (`id`, `person_idG`, `societyG`, `kvg_premiumG`, `statusG`, `modification_dateG`, `provisionG`, `cidG`, `selected`, `created_at`, `updated_at`) VALUES
(1, 101, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-07 14:24:24', '2022-02-07 14:24:36'),
(2, 6, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(3, 15, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_hausrat`
--

CREATE TABLE `costumer_status_hausrat` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idH` int(11) DEFAULT NULL,
  `societyH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kvg_premiumH` int(11) DEFAULT NULL,
  `statusH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateH` date DEFAULT NULL,
  `provisionH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidH` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_status_hausrat`
--

INSERT INTO `costumer_status_hausrat` (`id`, `person_idH`, `societyH`, `kvg_premiumH`, `statusH`, `modification_dateH`, `provisionH`, `cidH`, `selected`, `created_at`, `updated_at`) VALUES
(1, 101, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-02-07 14:24:24', '2022-02-07 14:24:36'),
(2, 6, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(3, 15, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_retchsschutz`
--

CREATE TABLE `costumer_status_retchsschutz` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idR` int(11) DEFAULT NULL,
  `productR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `durationR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statusR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateR` date DEFAULT NULL,
  `provisionR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidR` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_status_retchsschutz`
--

INSERT INTO `costumer_status_retchsschutz` (`id`, `person_idR`, `productR`, `durationR`, `statusR`, `modification_dateR`, `provisionR`, `cidR`, `selected`, `created_at`, `updated_at`) VALUES
(1, 101, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-07 14:24:24', '2022-02-07 14:24:36'),
(2, 6, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(3, 15, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_vorsorge`
--

CREATE TABLE `costumer_status_vorsorge` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idV` int(11) DEFAULT NULL,
  `societyV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productionV` int(11) DEFAULT NULL,
  `statusV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateV` date DEFAULT NULL,
  `provisionV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidV` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_status_vorsorge`
--

INSERT INTO `costumer_status_vorsorge` (`id`, `person_idV`, `societyV`, `productionV`, `statusV`, `modification_dateV`, `provisionV`, `cidV`, `selected`, `created_at`, `updated_at`) VALUES
(1, 101, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-07 14:24:24', '2022-02-07 14:24:36'),
(2, 6, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(3, 15, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `costumer_status_zusatzversicherung`
--

CREATE TABLE `costumer_status_zusatzversicherung` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_idZ` int(11) DEFAULT NULL,
  `societyZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vvg_premiumZ` int(11) DEFAULT NULL,
  `statusZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modification_dateZ` date DEFAULT NULL,
  `provisionZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidZ` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `costumer_status_zusatzversicherung`
--

INSERT INTO `costumer_status_zusatzversicherung` (`id`, `person_idZ`, `societyZ`, `vvg_premiumZ`, `statusZ`, `modification_dateZ`, `provisionZ`, `cidZ`, `selected`, `created_at`, `updated_at`) VALUES
(1, 101, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-07 14:24:24', '2022-02-07 14:24:36'),
(2, 6, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-14 07:41:38', '2022-02-14 07:49:26'),
(3, 15, NULL, NULL, 'notselected', NULL, NULL, NULL, 0, '2022-02-18 11:32:16', '2022-02-18 11:32:16');

-- --------------------------------------------------------

--
-- Table structure for table `deletedlead`
--

CREATE TABLE `deletedlead` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` int(11) NOT NULL,
  `date` date NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `family_person`
--

CREATE TABLE `family_person` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthdate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leads_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kundportfolio` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `family_person`
--

INSERT INTO `family_person` (`id`, `first_name`, `last_name`, `birthdate`, `leads_id`, `created_at`, `updated_at`, `status`, `status_updated_at`, `kundportfolio`) VALUES
(15, 'Myles Perkins', 'Cathleen Jefferson', '1992-11-17', 13, '2022-02-18 11:12:33', '2022-02-18 11:32:16', 'Open', '2022-02-18 12:12:33', 0),
(16, 'Sylvia Guthrie', 'Melyssa Perez', '2019-02-08', 13, '2022-02-18 11:12:33', '2022-02-18 11:12:33', 'Submited', '2022-02-18 12:12:33', 0),
(17, 'Sasha Drake', 'Honorato Daniel', '2013-08-02', 13, '2022-02-18 11:12:33', '2022-02-18 15:06:50', 'Done', '2022-02-18 12:12:33', 0),
(18, 'Nehru Blake', 'Laura Kim', '2001-01-07', 14, '2022-02-18 14:54:26', '2022-02-18 14:54:26', 'Open', '2022-02-18 15:54:26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdate` date DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` int(11) DEFAULT NULL,
  `latitude` double(11,8) DEFAULT NULL,
  `longitude` double(11,8) DEFAULT NULL,
  `number_of_persons` int(11) DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_task` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_contract` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `appointment_date` date DEFAULT NULL,
  `campaign_id` int(11) NOT NULL DEFAULT '1',
  `assign_to_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned` tinyint(1) NOT NULL DEFAULT '0',
  `wantsonline` tinyint(1) NOT NULL DEFAULT '0',
  `rejected` tinyint(1) NOT NULL DEFAULT '0',
  `zufriedenheit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gesundheit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bemerkung` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sprache` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `berater` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `first_name`, `last_name`, `telephone`, `birthdate`, `city`, `address`, `postal_code`, `latitude`, `longitude`, `number_of_persons`, `nationality`, `slug`, `status_task`, `status_contract`, `completed`, `appointment_date`, `campaign_id`, `assign_to_id`, `created_at`, `updated_at`, `time`, `assigned`, `wantsonline`, `rejected`, `zufriedenheit`, `gesundheit`, `bemerkung`, `sprache`, `berater`, `agent`) VALUES
(1, 'Bulzart', 'Aliu', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'SPfXJPtVuirshNUS', NULL, NULL, 0, '2022-02-16', 3, 5, '2022-02-16 12:38:11', '2022-02-16 12:51:36', '15:00', 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Bajram', 'Aliu', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'YeoWufUvmpjtshJW', NULL, NULL, 0, NULL, 3, 5, '2022-02-16 12:38:11', '2022-02-15 23:00:00', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Enis', 'Demolli', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'QYRYejWNMCullWGc', NULL, NULL, 0, NULL, 1, 5, '2022-02-16 12:38:11', '2022-02-15 23:00:00', NULL, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'albenit', 'Bytyqi', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'paAjwjtOQFhdKCzf', NULL, NULL, 0, NULL, 2, NULL, '2022-02-16 12:38:11', '2022-02-16 12:38:11', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Jasin', 'Bilalli', '045917726', '2000-08-26', NULL, 'Kosove', NULL, NULL, NULL, 3, NULL, 'SmUzZgOvkDQsbZfT', NULL, NULL, 0, NULL, 3, NULL, '2022-02-16 12:38:11', '2022-02-16 12:38:11', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Art', 'Shabani', '045464926', '2000-02-09', NULL, 'Prishtine', NULL, NULL, NULL, 2, NULL, 'kZGYNPgCZNnuzJPM', NULL, NULL, 0, NULL, 2, NULL, '2022-02-16 12:38:11', '2022-02-16 12:38:11', NULL, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Flori', 'Frrokaj', '045464926', '2000-02-10', NULL, 'Prishtine', NULL, NULL, NULL, 1, NULL, 'xSkmTeVisWtokIcr', NULL, NULL, 0, NULL, 1, NULL, '2022-02-16 12:38:11', '2022-02-16 12:38:11', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'Altin', 'Ahmetaj', '045464926', '2000-02-10', NULL, 'Prishtine', NULL, NULL, NULL, 2, NULL, 'TLEUAkElkUfojwLP', NULL, NULL, 0, NULL, 3, NULL, '2022-02-16 12:38:11', '2022-02-16 12:38:11', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Bulzart', 'Aliu', '416780380', NULL, 'zasawqsw', '6078 zasawqsw', 6078, 0.00000000, 0.00000000, 2, 'Schweizer', NULL, NULL, NULL, 0, '2022-03-03', 1, 6, '2021-03-15 16:51:39', '2022-02-16 14:16:07', '14:45', 1, 0, 0, NULL, NULL, 'Ich habe mit dem Mann den Termin vereinbart \nEr ist für den vergleich offen .', 'Deutsch', 'Youcall16.03 (Das ist kein Termin und  gesundheitliche Frage nicht gut gestellt ) ', 'Meyer'),
(10, 'Test', 'Test', '416780380', NULL, 'zasawqsw', '6078 zasawqsw', 6078, 0.00000000, 0.00000000, 2, 'Schweizer', NULL, NULL, NULL, 0, '2022-03-03', 1, 5, '2021-03-15 16:51:39', '2022-02-16 13:52:23', '15:00', 1, 0, 0, NULL, NULL, 'Ich habe mit dem Mann den Termin vereinbart \nEr ist für den vergleich offen .', 'Deutsch', 'Youcall16.03 (Das ist kein Termin und  gesundheitliche Frage nicht gut gestellt ) ', 'Meyer'),
(11, 'Test', 'Test', '416780380', NULL, 'zasawqsw', '6078 zasawqsw', 6078, 0.00000000, 0.00000000, 2, 'Schweizer', NULL, NULL, NULL, 0, '2022-03-03', 1, 5, '2021-03-15 16:51:39', '2022-02-16 13:25:32', '15:00', 1, 0, 0, NULL, NULL, 'Ich habe mit dem Mann den Termin vereinbart \nEr ist für den vergleich offen .', 'Deutsch', 'Youcall16.03 (Das ist kein Termin und  gesundheitliche Frage nicht gut gestellt ) ', 'Meyer'),
(12, 'Kimberley Wood', 'Tanya Leach', 'Olga Acosta', NULL, 'Miranda WalterWesley Hyde', 'Kosovo', 94, 42.60263590, 20.90297700, 41, 'Galvin Houston', 'kimberley-wood-12', NULL, NULL, 0, '2022-02-18', 0, NULL, '2022-02-18 11:11:14', '2022-02-18 11:11:14', '16:00', 1, 1, 0, 'Charlotte Greene', NULL, 'Facere vel et volupt', 'Farrah Nolan', 'Katelyn Owen', 'Trevor Golden'),
(13, 'Gavin Dillard', 'Phoebe Mcguire', 'Oprah Richmond', NULL, 'Craig JacksonHarriet Bowen', 'Prishtine', 58, 42.66291380, 21.16550280, 3, 'Velma Silva', 'gavin-dillard-13', 'open', NULL, 1, '2022-02-18', 0, 5, '2022-02-18 11:12:09', '2022-02-18 11:12:33', '05:01', 1, 0, 0, 'Aline Clements', NULL, 'Nisi est nostrum qua', 'Farrah Mccormick', 'Harlan Barrera', 'Pamela Webb'),
(14, 'Dawn Powers', 'Brielle Peters', 'Timothy Gardner', NULL, 'Priscilla PatelNicholas Carver', 'Kosovo', 9, 42.60263590, 20.90297700, 16, 'Griffin Mayer', 'dawn-powers-14', 'open', NULL, 1, '2022-02-18', 0, 7, '2022-02-18 14:53:51', '2022-02-18 14:54:26', '03:38', 1, 0, 0, 'Ivory Mcfadden', NULL, 'Magni hic magni volu', 'Cara Sweeney', 'Deborah Knowles', 'Kessie Hester'),
(15, 'Dawn Powers', 'Brielle Peters', 'Timothy Gardner', NULL, 'Priscilla PatelNicholas Carver', 'Kosovo', 9, 42.60263590, 20.90297700, 16, 'Griffin Mayer', 'dawn-powers-15', NULL, NULL, 0, '2022-02-18', 0, 5, '2022-02-18 14:54:06', '2022-02-18 14:54:06', '03:38', 1, 0, 0, 'Ivory Mcfadden', NULL, 'Magni hic magni volu', 'Cara Sweeney', 'Deborah Knowles', 'Kessie Hester');

-- --------------------------------------------------------

--
-- Table structure for table `leads_history`
--

CREATE TABLE `leads_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads_history`
--

INSERT INTO `leads_history` (`id`, `leads_id`, `image`, `status`, `admin_id`, `created_at`, `updated_at`) VALUES
(1, 6, NULL, 'Falsche nummer', 5, '2022-02-05 13:10:45', '2022-02-05 13:10:45');

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_a_counteroffered`
--

CREATE TABLE `lead_data_a_counteroffered` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `upload_police` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comparison_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_fahrzeug`
--

CREATE TABLE `lead_data_fahrzeug` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `upload_police` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leasing` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leasing_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_of_purchase` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placing_on_the_market` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance_date` date DEFAULT NULL,
  `redeemed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `km_stood` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issue_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `most_common` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deductible` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `carried` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_shop` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accident_coverage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `traffic_legal_protection` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grossly` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `glass_protection` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parking_damage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hour_breakdown_assistance` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0',
  `mandatiert` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_kk`
--

CREATE TABLE `lead_data_kk` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `pre_insurer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_required` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notice_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `power_of_attorney` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_s`
--

CREATE TABLE `lead_data_s` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `residence_permit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone_nr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zivilstand` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employment_relationship` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_frequency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_per_month` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `share_guarantee` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_of_contract` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `premium_exemption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eu_pension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `death_benefit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smoker` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desired` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nationality_sachen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_data_s_w`
--

CREATE TABLE `lead_data_s_w` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `upload_police` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comparison_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_of_people` int(11) DEFAULT NULL,
  `number_of_rooms` int(11) DEFAULT NULL,
  `sum_insured` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desired_additional_coverage` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personal_liability` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `n_of_p_legal_protection` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accepted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_info`
--

CREATE TABLE `lead_info` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` int(11) NOT NULL,
  `krankenkasse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wichtig` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bewertung` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grund` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kampagne` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `teilnahme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_info`
--

INSERT INTO `lead_info` (`id`, `lead_id`, `krankenkasse`, `wichtig`, `bewertung`, `grund`, `kampagne`, `created_at`, `updated_at`, `teilnahme`) VALUES
(1, 1, 'Numquam sequi cum of', 'Dolore et dicta accu', 'Quia rerum dolor aut', 'At libero accusamus', 'Eveniet corrupti l', '2022-02-03 12:21:33', '2022-02-03 12:21:33', '0000-00-00 00:00:00'),
(2, 133, 'Krankenkasse 1', 'Nicht', 'Nicht', 'Grund 1', 'Kampagne 1', '2022-02-04 11:31:54', '2022-02-04 11:31:54', '2022-02-04 12:31:54'),
(3, 122, 'Krankenkasse', 'Nicht', 'Nicht', 'Grund', 'Kampagne', '2022-02-04 13:02:24', '2022-02-04 13:02:24', '2022-02-04 14:02:24'),
(4, 123, 'Krankenkasse', 'Nicht', 'Nicht', 'Grund', 'Kampagne', '2022-02-04 13:02:47', '2022-02-04 13:02:47', '2022-02-04 14:02:47'),
(5, 124, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:06:40', '2022-02-05 08:06:40', '2022-02-05 09:06:40'),
(6, 124, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:06:40', '2022-02-05 08:06:40', '2022-02-05 09:06:40'),
(7, 126, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:06:40', '2022-02-05 08:06:40', '2022-02-05 09:06:40'),
(8, 124, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:06:40', '2022-02-05 08:06:40', '2022-02-05 09:06:40'),
(9, 124, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:06:40', '2022-02-05 08:06:40', '2022-02-05 09:06:40'),
(10, 129, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:08:46', '2022-02-05 08:08:46', '2022-02-05 09:08:46'),
(11, 129, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:08:46', '2022-02-05 08:08:46', '2022-02-05 09:08:46'),
(12, 131, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:08:46', '2022-02-05 08:08:46', '2022-02-05 09:08:46'),
(13, 129, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:08:46', '2022-02-05 08:08:46', '2022-02-05 09:08:46'),
(14, 129, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 08:08:46', '2022-02-05 08:08:46', '2022-02-05 09:08:46'),
(15, 1, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 12:56:52', '2022-02-05 12:56:52', '2022-02-05 13:56:52'),
(16, 2, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 12:56:52', '2022-02-05 12:56:52', '2022-02-05 13:56:52'),
(17, 3, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 12:56:52', '2022-02-05 12:56:52', '2022-02-05 13:56:52'),
(18, 4, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 12:56:52', '2022-02-05 12:56:52', '2022-02-05 13:56:52'),
(19, 5, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 12:56:52', '2022-02-05 12:56:52', '2022-02-05 13:56:52'),
(20, 6, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:07:09', '2022-02-05 13:07:09', '2022-02-05 14:07:09'),
(21, 7, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:07:09', '2022-02-05 13:07:09', '2022-02-05 14:07:09'),
(22, 8, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:07:09', '2022-02-05 13:07:09', '2022-02-05 14:07:09'),
(23, 9, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:07:09', '2022-02-05 13:07:09', '2022-02-05 14:07:09'),
(24, 10, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:07:09', '2022-02-05 13:07:09', '2022-02-05 14:07:09'),
(25, 11, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:31:58', '2022-02-05 13:31:58', '2022-02-05 14:31:58'),
(26, 12, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:31:58', '2022-02-05 13:31:58', '2022-02-05 14:31:58'),
(27, 13, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:31:58', '2022-02-05 13:31:58', '2022-02-05 14:31:58'),
(28, 14, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:31:58', '2022-02-05 13:31:58', '2022-02-05 14:31:58'),
(29, 15, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-05 13:31:58', '2022-02-05 13:31:58', '2022-02-05 14:31:58'),
(30, 16, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:48:50', '2022-02-06 16:48:50', '2022-02-06 17:48:50'),
(31, 17, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:48:50', '2022-02-06 16:48:50', '2022-02-06 17:48:50'),
(32, 18, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:48:50', '2022-02-06 16:48:50', '2022-02-06 17:48:50'),
(33, 19, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:48:50', '2022-02-06 16:48:50', '2022-02-06 17:48:50'),
(34, 20, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:48:50', '2022-02-06 16:48:50', '2022-02-06 17:48:50'),
(35, 21, 'Megan Gilliam', 'Vincent Santana', 'Kane Weaver', 'Yael Crane', 'Stacey Carrillo', '2022-02-06 16:49:37', '2022-02-06 16:49:37', '1976-04-21 22:00:00'),
(36, 101, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:58:05', '2022-02-06 16:58:05', '2022-02-06 17:58:05'),
(37, 102, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:58:05', '2022-02-06 16:58:05', '2022-02-06 17:58:05'),
(38, 103, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:58:05', '2022-02-06 16:58:05', '2022-02-06 17:58:05'),
(39, 104, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:58:05', '2022-02-06 16:58:05', '2022-02-06 17:58:05'),
(40, 105, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 16:58:05', '2022-02-06 16:58:05', '2022-02-06 17:58:05'),
(41, 106, 'Florence Cardenas', 'Dominique Hooper', 'Sara Blair', 'Fritz Romero', 'Shoshana Dillard', '2022-02-06 16:58:21', '2022-02-06 16:58:21', '1983-07-12 22:00:00'),
(42, 107, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 17:08:21', '2022-02-06 17:08:21', '2022-02-06 18:08:21'),
(43, 108, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 17:08:21', '2022-02-06 17:08:21', '2022-02-06 18:08:21'),
(44, 109, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 17:08:21', '2022-02-06 17:08:21', '2022-02-06 18:08:21'),
(45, 110, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 17:08:21', '2022-02-06 17:08:21', '2022-02-06 18:08:21'),
(46, 111, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-06 17:08:21', '2022-02-06 17:08:21', '2022-02-06 18:08:21'),
(47, 118, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:08:42', '2022-02-07 12:08:42', '2022-02-07 13:08:42'),
(48, 119, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:08:42', '2022-02-07 12:08:42', '2022-02-07 13:08:42'),
(49, 120, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:08:42', '2022-02-07 12:08:42', '2022-02-07 13:08:42'),
(50, 121, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:08:42', '2022-02-07 12:08:42', '2022-02-07 13:08:42'),
(51, 122, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:08:42', '2022-02-07 12:08:42', '2022-02-07 13:08:42'),
(52, 123, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:09:11', '2022-02-07 12:09:11', '2022-02-07 13:09:11'),
(53, 124, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:09:11', '2022-02-07 12:09:11', '2022-02-07 13:09:11'),
(54, 125, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:09:11', '2022-02-07 12:09:11', '2022-02-07 13:09:11'),
(55, 126, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:09:11', '2022-02-07 12:09:11', '2022-02-07 13:09:11'),
(56, 127, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-07 12:09:11', '2022-02-07 12:09:11', '2022-02-07 13:09:11'),
(57, 2, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-08 08:04:24', '2022-02-08 08:04:24', '2022-02-08 09:04:24'),
(58, 3, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-08 08:04:24', '2022-02-08 08:04:24', '2022-02-08 09:04:24'),
(59, 4, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-08 08:04:24', '2022-02-08 08:04:24', '2022-02-08 09:04:24'),
(60, 5, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-08 08:04:24', '2022-02-08 08:04:24', '2022-02-08 09:04:24'),
(61, 6, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-08 08:04:24', '2022-02-08 08:04:24', '2022-02-08 09:04:24'),
(62, 7, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:19:25', '2022-02-09 08:19:25', '2022-02-09 09:19:25'),
(63, 8, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:19:25', '2022-02-09 08:19:25', '2022-02-09 09:19:25'),
(64, 9, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:19:25', '2022-02-09 08:19:25', '2022-02-09 09:19:25'),
(65, 10, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:19:25', '2022-02-09 08:19:25', '2022-02-09 09:19:25'),
(66, 11, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:19:25', '2022-02-09 08:19:25', '2022-02-09 09:19:25'),
(67, 12, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:45:10', '2022-02-09 08:45:10', '2022-02-09 09:45:10'),
(68, 13, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:45:10', '2022-02-09 08:45:10', '2022-02-09 09:45:10'),
(69, 14, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:45:10', '2022-02-09 08:45:10', '2022-02-09 09:45:10'),
(70, 15, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:45:10', '2022-02-09 08:45:10', '2022-02-09 09:45:10'),
(71, 16, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 08:45:10', '2022-02-09 08:45:10', '2022-02-09 09:45:10'),
(72, 17, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:37:10', '2022-02-09 13:37:10', '2022-02-09 14:37:10'),
(73, 18, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:37:10', '2022-02-09 13:37:10', '2022-02-09 14:37:10'),
(74, 19, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:37:10', '2022-02-09 13:37:10', '2022-02-09 14:37:10'),
(75, 20, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:37:10', '2022-02-09 13:37:10', '2022-02-09 14:37:10'),
(76, 21, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:37:10', '2022-02-09 13:37:10', '2022-02-09 14:37:10'),
(77, 22, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:40:45', '2022-02-09 13:40:45', '2022-02-09 14:40:45'),
(78, 23, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:40:45', '2022-02-09 13:40:45', '2022-02-09 14:40:45'),
(79, 24, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:40:45', '2022-02-09 13:40:45', '2022-02-09 14:40:45'),
(80, 25, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:40:45', '2022-02-09 13:40:45', '2022-02-09 14:40:45'),
(81, 26, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-09 13:40:45', '2022-02-09 13:40:45', '2022-02-09 14:40:45'),
(82, 1, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-16 12:38:11', '2022-02-16 12:38:11', '2022-02-16 13:38:11'),
(83, 2, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-16 12:38:11', '2022-02-16 12:38:11', '2022-02-16 13:38:11'),
(84, 3, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-16 12:38:11', '2022-02-16 12:38:11', '2022-02-16 13:38:11'),
(85, 4, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-16 12:38:11', '2022-02-16 12:38:11', '2022-02-16 13:38:11'),
(86, 5, 'Krank 1', 'None', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-16 12:38:11', '2022-02-16 12:38:11', '2022-02-16 13:38:11'),
(87, 6, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-16 12:38:11', '2022-02-16 12:38:11', '2022-02-16 13:38:11'),
(88, 7, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-16 12:38:11', '2022-02-16 12:38:11', '2022-02-16 13:38:11'),
(89, 8, 'Krank 1', 'Wichtig 1', 'Bewertung 1', 'Grund 1', 'Kampagne 1', '2022-02-16 12:38:11', '2022-02-16 12:38:11', '2022-02-16 13:38:11');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_11_25_104229_costumers_table_migration', 1),
(6, '2021_11_25_122936_create_admins_table', 1),
(7, '2021_11_27_132304_create_leads_table', 1),
(8, '2021_11_27_142414_change_campaign_leads', 1),
(9, '2021_11_27_152057_add_unsigned_leads', 1),
(10, '2021_11_29_105505_add_completed_leads', 1),
(11, '2021_11_29_150416_add_address_leads', 1),
(12, '2021_11_30_105617_lead_add_fields', 1),
(13, '2021_11_30_151111_add_lead_online', 1),
(14, '2021_12_01_095352_create_chats_table', 1),
(15, '2021_12_01_153328_add_app_field', 1),
(16, '2021_12_04_113832_appointment_add_time', 1),
(17, '2021_12_04_132939_add_slug_leads', 1),
(18, '2021_12_06_144011_create_appointments_table', 1),
(19, '2021_12_07_133128_rejected_leads', 1),
(21, '2021_12_16_130603_deletedlead', 1),
(22, '2021_12_21_134427_add_assign_date', 1),
(23, '2021_12_21_143920_create_todos_table', 1),
(24, '2021_12_21_173622_create_tasks_table', 1),
(25, '2021_12_22_091851_add_table_trainings', 1),
(26, '2021_12_22_104145_add_latlong_csapp', 1),
(27, '2021_12_25_140442_add_duration_leads', 1),
(28, '2021_12_27_142212_create_admin_appointments_table', 1),
(29, '2021_12_27_143435_create_permission_tables', 1),
(30, '2021_12_27_171034_leads', 1),
(31, '2021_12_27_172337_family_person', 1),
(32, '2021_12_27_172634_lead_data_kk', 1),
(33, '2021_12_27_173014_lead_data_a_counteroffered', 1),
(34, '2021_12_27_173220_lead_data_s', 1),
(35, '2021_12_27_173824_lead_data_s_w', 1),
(36, '2021_12_27_174239_lead_data_fahrzeug', 1),
(37, '2021_12_28_155733_add_time_leads_as_appointment', 1),
(38, '2021_12_29_121151_add_status_family', 1),
(39, '2021_12_29_152931_create_campaign_table', 1),
(40, '2021_12_30_103848_add_accepted_status', 1),
(41, '2021_12_30_134129_add_status_time', 1),
(42, '2021_12_31_100929_add_time_trainings', 1),
(43, '2022_01_03_172744_add_pendencies_table', 1),
(44, '2022_01_07_095722_create_teams_table', 1),
(45, '2022_01_07_095957_create_team_consultants_table', 1),
(46, '2022_01_08_111143_create_chat_tables', 1),
(47, '2022_01_11_123245_test', 1),
(48, '2022_01_24_142241_personal_appointment_table', 1),
(49, '2022_01_25_151625_table_costumer_status_grundversicherung', 1),
(50, '2022_01_25_154921_table_costumer_status_zusatzversicherung', 1),
(51, '2022_01_25_155250_table_costumer_status_retchsschutz', 1),
(52, '2022_01_25_155642_table_costumer_status_hausrat', 1),
(53, '2022_01_25_155841_table_costumer_status_vorsorge', 1),
(54, '2022_01_26_135245_table_costumer_produkt_grundversicherung', 1),
(55, '2022_01_26_142438_table_costumer_produkt_zusatzversicherung', 1),
(56, '2022_01_26_145110_table_costumer_produkt_rechtsschutz', 1),
(57, '2022_01_26_145802_table_costumer_produkt_vorsorge', 1),
(58, '2022_01_27_084059_add_complete_costumer_form', 1),
(59, '2022_01_27_142916_leads_history', 1),
(60, '2022_01_29_154710_add_rejected_field', 1),
(61, '2022_01_31_091438_table_costumer_produkt_autoversicherung', 1),
(62, '2022_01_31_091525_table_costumer_produkt_hausrat', 1),
(63, '2022_02_01_112335_add_berater_leads', 2),
(64, '2022_02_03_130427_lead_info', 3),
(65, '2022_02_04_144000_add_comment_in_todos', 4),
(66, '2022_02_05_004731_add_pendency_id', 4),
(67, '2022_02_05_100724_add_agent_table_leads', 5),
(68, '2022_02_05_100724_add_agent_table_leads', 1),
(69, '2022_02_09_150454_add_date_at_personal_app', 6),
(74, '2022_02_12_121145_add_type_pendency', 8),
(75, '2022_02_12_102106_create_notifications_table', 9),
(79, '2022_02_14_124732_create_notifications_table', 10),
(80, '2022_02_15_094109_add_mandatiert_field', 11);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\Admins', 2),
(2, 'App\\Models\\Admins', 3),
(3, 'App\\Models\\Admins', 4),
(7, 'App\\Models\\Admins', 5),
(7, 'App\\Models\\Admins', 6),
(7, 'App\\Models\\Admins', 7),
(7, 'App\\Models\\Admins', 8),
(6, 'App\\Models\\Admins', 9);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('05d4586b-688a-467e-acb4-b95341d16a6f', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6Imc5dSs5c0s2WHl2UU1kb0Nld2EvQnc9PSIsInZhbHVlIjoiSW1ITlNhd3ZFSlc5NXpBWENrTmNDUT09IiwibWFjIjoiODlmYjM1Y2UzNDAwMDY3YmU0YmM0ZDhiMzZlYTEzNjc1OTg2MzViNjU2OGE3ZDJlNjI2MDE0ZWMyNjNhNGNmNCIsInRhZyI6IiJ9\\/eyJpdiI6ImxkTkhoL2p1TFFVZGxNWU00dzlZS0E9PSIsInZhbHVlIjoiRDZlYndnb3A4R0lFVnBRbUVwNWFmUT09IiwibWFjIjoiYTcyN2VlZGQ4NjZlZmFiNTE1YzZmY2JiMGE2ZGM3NDFiYjhhYmIxMGVjMmEzMWFkNzI1OWEyNjFlYmQyM2NkZCIsInRhZyI6IiJ9?pend_id=77\\\"> Documentation for :Sasha Drake has been submitted <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:39:11', '2022-02-18 15:11:14'),
('112296e0-48bb-45c4-b388-1cffaef431c4', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/tasks\\\">There are added 1 persons from an appointment <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:54:26', '2022-02-18 15:11:14'),
('1d268301-1d03-4964-b422-d0c95934ea32', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6IlAwUTdIWXlkTWdpcUpvNmZUYlV0YXc9PSIsInZhbHVlIjoidVJsb1VBL3NLQUgvdkVUdTVDQ1R6Zz09IiwibWFjIjoiNGI1NmRlMTU1OThmMjVmMTY0YzI5YmNkYTNmNGQxNmU0MDcwMDcyMmE5NmVhODdlZGNjYTczNGRjZWEwMGJiNyIsInRhZyI6IiJ9\\/eyJpdiI6IlZEMHduaSthRXNBK3FkVW5TMWl4aWc9PSIsInZhbHVlIjoiVVk1Z3crTDVqWFRSZ1pRcXNEbmw4dz09IiwibWFjIjoiOTk1NmI0ZTYyMTQ2Mjk2ZmFjYTE1MjFhMzc3ZmI2YjRhZjQyMzk4OWQ5NzhmNTMzNjYyMzIzNTFmMjM4NmY4YSIsInRhZyI6IiJ9?pend_id=77\\\"> Documentation for :Sasha Drake has been submitted <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:43:17', '2022-02-18 15:11:14'),
('1d8b4c34-d53f-414b-b77e-edbf0cee2d19', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/costumer_form\\/eyJpdiI6IndNRGxtQjE2Qys5clpFMmhEdExTNXc9PSIsInZhbHVlIjoiQ2g1c2dkZnlBQnR3eW1wYXBBKzg1QT09IiwibWFjIjoiNzQ2NjA4NTkxNTcyZGYzYjAwNmFhMTAxZTQzZTBjYjY0Y2NjZjUwNmMzOWQ2OTZhMzlkZTM1M2Q3MDE4Nzk1OCIsInRhZyI6IiJ9\\\"> Documentation for :Sylvia Guthrie has been submitted<\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 13:32:08', '2022-02-18 15:11:14'),
('2958bf2e-a4e7-4513-9869-aea5a61e57db', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6IkZNRjdhcEovcDMxODdJVllGUVFpbHc9PSIsInZhbHVlIjoicnpqOGREUkxsZm1ZTzZmMTFjSEpCZz09IiwibWFjIjoiMWJjM2EyOTc3MGY1MTI2Zjk1YzQ0OTg2NjY2OWRjMzk1Nzg3ZDYxMjE3ZDY2ZWYyMGVhOGQzZTNiMGEwNTAzMiIsInRhZyI6IiJ9\\/eyJpdiI6IkNtdVJ1akZzQmd3STJPbFgxUFJ0elE9PSIsInZhbHVlIjoiNjA1QmpXSk1kSFllSkk3SUJFL21WQT09IiwibWFjIjoiNDM1OWIzYzM1Y2YzMzkxYjljZjM4MTBlZTVjYjgwMjk5NGNkNDNiM2U4YzY0Y2EzOGFmY2JjYzBhYWMxMTg1MSIsInRhZyI6IiJ9?pend_id=77\\\"> Documentation for :Sasha Drake has been submitted <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:39:49', '2022-02-18 15:11:14'),
('46442fe3-983a-4c93-ab5f-1288b559edd1', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6Ik4yV3hnOTIrM3Q3aEVNVjRHNFFlcWc9PSIsInZhbHVlIjoiUlk5K0F6b3pibXN6VVFiMDJMZG1JUT09IiwibWFjIjoiNmMxNDczM2U5ZTI2YzIxMWZjZWUwNTM5ZDdmMjI4NmVkNmQzMTk0NzM3Y2ZkYzgzYTc1ZjAzMzA4NTM1OGUxMSIsInRhZyI6IiJ9\\/eyJpdiI6InhyejRBYW9mZnUxL3VsM2F3UkNWc2c9PSIsInZhbHVlIjoiNnM2NFNsSjZEOGc3LzB0dHpIM3BKZz09IiwibWFjIjoiYzQyYTI3OWNjYjc0NWY5NWRhMmM1Mzk3ZTJhZDVkMGMzZTRiY2MxMDM3NjkzMWVmMmQ2MGQzNWU3MTU0OWU3MyIsInRhZyI6IiJ9?pend_id=77\\\"> Documentation for :Sasha Drake has been submitted <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:38:30', '2022-02-18 15:11:14'),
('5ceed365-cb61-4590-b45c-fa071cd1be2a', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/costumer_form\\/eyJpdiI6IlR4NlhSOHVEMVVRbnp1WFBlcm9BbEE9PSIsInZhbHVlIjoiN1h4N3hBbDdQcWIxRXR5MFhPSlFHQT09IiwibWFjIjoiY2E4YTQ1MjEyY2UwN2Y0YzIyMDc0NmQxZTI5YTU2MjgzZTBlNTc5OTVmNGRlOThjYzhmM2E0ZmZiZGFkYzc3ZCIsInRhZyI6IiJ9\\\"> Documentation for :Sasha Drake has been submitted<\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 15:06:43', '2022-02-18 15:11:14'),
('63266fe7-196e-4b19-b7a3-b110ed32545a', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/costumer_form\\/eyJpdiI6InZaRGdPeCtiZjAxZE5VSWU3SDdWY2c9PSIsInZhbHVlIjoiWUZyLy9ZTVh6S0EvQUVOd1h0clhqQT09IiwibWFjIjoiYTM5ZmU3MjY0NWJmOGFjNGJlN2RhNmI4OGI0ODMxZTJhOWRhMDVmZTk4YWQzMDViNzEyYjFjNGViYWQwOGUyYiIsInRhZyI6IiJ9\\\"> Documentation for :Sylvia Guthrie has been submitted<\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:44:56', '2022-02-18 15:11:14'),
('793e0f9d-c295-4101-8f62-e0a4f1b849c1', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/costumer_form\\/eyJpdiI6Im1XcUFEcUQ2MFplUEdEVjUxbURKRmc9PSIsInZhbHVlIjoiQVdPRSs2Y2RzOVd2MHZBeitUVkFqQT09IiwibWFjIjoiMTBhMGFmNTU3ZWMxNjMyNzEzMjBjNjUxZDk4NzMxOGJmY2RmOTNlNjA2OWQxZmRhY2RhNWZjOTNmN2VmODM5OCIsInRhZyI6IiJ9\\\"> Documentation for :Sasha Drake has been submitted<\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 13:58:48', '2022-02-18 15:11:14'),
('7a197ad2-abb4-48ce-aa78-22f4e94af612', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6IjhESU11NFJQSVN1VmwxLzZ2dGtVaWc9PSIsInZhbHVlIjoiQ05zbVNMT0pVeXVLMTVCakpzWDRiQT09IiwibWFjIjoiMTlhMTgyNjM3Mjk4NDhkZDQ5Y2ZkZmQxNTJhYmU2NTBlYWRmYTUzNDFjMDdhZjEwZDdlMDdjMjEyZjc4YTE5YSIsInRhZyI6IiJ9\\/eyJpdiI6Ik5aY1N0dTBsZUFoR1gyNk55Qzhna1E9PSIsInZhbHVlIjoibEYwUVFaUzYrbTNaM3FPdUhhbFVUUT09IiwibWFjIjoiMWY4MDEzZDgwYzQ3YTQ1ZjM5YmI4YmZkM2ZmOWZhNGI3NzU4MDEwOWU3YWQ5MTczNzk4MGJhZWQwY2QxNTVhMyIsInRhZyI6IiJ9?pend_id=77\\\"> Documentation for :Sasha Drake has been submitted <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:43:06', '2022-02-18 15:11:14'),
('86f9c3d6-cc0b-4ebe-908b-fc3ff2d31e80', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6IlF1V1Fjalo1T1ZzcTRpWE1JdStHTWc9PSIsInZhbHVlIjoiUExwTStGVTh4clk1L0lOZlhkUFExZz09IiwibWFjIjoiMDUyNmJhZjM1NjljOGRjYzgyNzJhMmNlMmMwMjhhYjhjY2M4M2NhOGM4OTM0MGNiYmM1NDNkODE2YzlkOGMyOCIsInRhZyI6IiJ9\\/eyJpdiI6IlRHbjg2Q1g0bmRHQ1RmWWhnWm5abGc9PSIsInZhbHVlIjoiR3NZZ1VzcXZTUGdrRThPQ1dOZ0pjdz09IiwibWFjIjoiNjdlOTg2MTE4OWYzZjJmNDhiMWMxNWE5NjJkOGU0NmRiYTczNThkNDE0MDFlYzBjZWUxMTU1ZDlhYjE5ZjAyOSIsInRhZyI6IiJ9?pend_id=76\\\"> Documentation for :Sylvia Guthrie has been submitted <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:50:34', '2022-02-18 15:11:14'),
('8f8cd8ff-6960-4647-bf0d-4abb66ffa09e', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6IjhTTGM5TFYzYnY3U1FmSG51Y05pa1E9PSIsInZhbHVlIjoiOU9nbkhCMDNrR0hkczVFTHRJYk5MZz09IiwibWFjIjoiYjFlZjIzMTdkMzRmNjUxNGY0N2E0NzIyNmVhNTQ3Y2I1MzBjYzJhZWY2ZDEzNDZlNGViZDYzYzgwOWNiNzY5NSIsInRhZyI6IiJ9\\/eyJpdiI6IkI1RTJOcjlKcGpGalZ2MVdLK1V5SGc9PSIsInZhbHVlIjoiMVh3cDlpbjh6SUN5dWdpT3pzZWxoZz09IiwibWFjIjoiOTdiODFiZDI4NjlkMzE4NzRmOTM5NTY5NDY3MmI3ZmQyMGRlYzViMmFiMjcxOWM0NWJmMzQ5MjVmOTFlM2JiOCIsInRhZyI6IiJ9?pend_id=76\\\"> Documentation for :Sylvia Guthrie has been submitted <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:51:56', '2022-02-18 15:11:14'),
('b53d3c4d-0367-4d60-b58c-708cd35062c6', 'App\\Notifications\\SendNotificationn', 'App\\Models\\Admins', 3, '\"<a href=\\\"http:\\/\\/127.0.0.1:8000\\/leadfamilyperson\\/eyJpdiI6IkxGVXJDTk95TFdFOEhYaFk1dmcvUFE9PSIsInZhbHVlIjoiS2tjTGJCRnBycklpT2x6bkRDTC9ndz09IiwibWFjIjoiNjU4ZmE4Nzk1MThhYTVkZTQwZjIzYjBkZWZmNTNmY2UxZThkZTEwMGM5ZWFjYTVkM2I5YWQ2MTQzZTI5ZTk3ZCIsInRhZyI6IiJ9\\/eyJpdiI6IkJlRVdTNjBOMzh0YnRnMENVL2NadXc9PSIsInZhbHVlIjoiV3A0TGhjVXBrM2Jvb3dWclZRYUNBQT09IiwibWFjIjoiZTk4ODJkYmNmMzJlYTA0OTQ3MmE3Y2YxNTFhYzZkODhlMmY0ZjViM2MxNjA4M2Y2MzQwZTYwYTk0NzdiZmNmMSIsInRhZyI6IiJ9?pend_id=76\\\"> Documentation for :Sylvia Guthrie has been submitted <\\/a>\"', '2022-02-18 15:11:14', '2022-02-18 14:52:20', '2022-02-18 15:11:14');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pendencies`
--

CREATE TABLE `pendencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `family_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personalappointment`
--

CREATE TABLE `personalappointment` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` time NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `AppOrCon` int(11) NOT NULL,
  `assignfrom` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personalappointment`
--

INSERT INTO `personalappointment` (`id`, `title`, `time`, `address`, `comment`, `user_id`, `AppOrCon`, `assignfrom`, `created_at`, `updated_at`, `date`) VALUES
(1, 'Sot meeting', '14:13:00', 'Kosove', 'Test', 5, 1, 2, '2022-02-09 09:13:35', '2022-02-09 09:13:35', '2022-02-11'),
(2, 'Konsultim', '08:20:00', 'Ferizaj', 'aaaaaaaaaaaaaaa', 2, 1, 4, '2022-02-10 09:12:40', '2022-02-10 09:12:40', '2022-02-10'),
(3, 'Dicta et tempore cu', '17:33:00', 'Dolor facere aliquam', 'Cupidatat ut dolorum', 2, 1, 2, '2022-02-10 09:13:14', '2022-02-10 09:13:14', '2022-02-10'),
(4, 'Albeniti', '04:35:00', 'Proident esse bland', 'Modi consequuntur ex', 2, 1, 2, '2022-02-11 08:57:53', '2022-02-11 08:57:53', '2003-10-29'),
(5, 'Takimi per Dokumenta', '14:46:00', 'Nzyre', 'Si ke Kry do sene bre burr', 5, 1, 2, '2022-02-11 09:36:45', '2022-02-11 09:36:45', '2022-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rejectedleads`
--

CREATE TABLE `rejectedleads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `leads_id` int(11) NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(2, 'backoffice', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(3, 'salesmanager', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(4, 'management', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(5, 'finance', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(6, 'digital', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24'),
(7, 'fs', 'admins', '2022-01-31 15:04:24', '2022-01-31 15:04:24');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sales_manager_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_consultants`
--

CREATE TABLE `team_consultants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `team_id` int(11) NOT NULL,
  `consultant_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE `todos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendency_id` bigint(20) DEFAULT NULL,
  `costumer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `todos`
--

INSERT INTO `todos` (`id`, `admin_id`, `pendency_id`, `costumer`, `text`, `comment`, `number`, `done`, `created_at`, `updated_at`) VALUES
(1, '3', NULL, NULL, '123', NULL, '1', 0, '2022-02-09 07:34:22', '2022-02-09 07:34:22'),
(2, '3', NULL, NULL, '4444444', NULL, '1', 0, '2022-02-18 11:06:55', '2022-02-18 11:06:55');

-- --------------------------------------------------------

--
-- Table structure for table `trainings`
--

CREATE TABLE `trainings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` bigint(20) UNSIGNED DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin` bigint(20) DEFAULT NULL,
  `confirmed` tinyint(1) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_another_item_g`
--
ALTER TABLE `add_another_item_g`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `admin_appointments`
--
ALTER TABLE `admin_appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chats_costumer_id_index` (`costumer_id`),
  ADD KEY `chats_admin_id_index` (`admin_id`),
  ADD KEY `chats_rating_index` (`rating`);

--
-- Indexes for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chat_messages_participation_id_foreign` (`participation_id`),
  ADD KEY `chat_messages_conversation_id_foreign` (`conversation_id`);

--
-- Indexes for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `participation_message_index` (`participation_id`,`message_id`),
  ADD KEY `chat_message_notifications_message_id_foreign` (`message_id`),
  ADD KEY `chat_message_notifications_conversation_id_foreign` (`conversation_id`);

--
-- Indexes for table `chat_participation`
--
ALTER TABLE `chat_participation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `participation_index` (`conversation_id`,`messageable_id`,`messageable_type`);

--
-- Indexes for table `costumers`
--
ALTER TABLE `costumers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `costumers_name_index` (`name`),
  ADD KEY `costumers_surname_index` (`surname`),
  ADD KEY `costumers_email_index` (`email`),
  ADD KEY `costumers_dateofbirth_index` (`dateofbirth`),
  ADD KEY `costumers_phone_index` (`phone`),
  ADD KEY `costumers_health_index` (`health`);

--
-- Indexes for table `costumer_podukt_zusatzversicherung`
--
ALTER TABLE `costumer_podukt_zusatzversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_autoversicherung`
--
ALTER TABLE `costumer_produkt_autoversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_grundversicherung`
--
ALTER TABLE `costumer_produkt_grundversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_hausrat`
--
ALTER TABLE `costumer_produkt_hausrat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_rechtsschutz`
--
ALTER TABLE `costumer_produkt_rechtsschutz`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_produkt_vorsorge`
--
ALTER TABLE `costumer_produkt_vorsorge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_grundversicherung`
--
ALTER TABLE `costumer_status_grundversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_hausrat`
--
ALTER TABLE `costumer_status_hausrat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_retchsschutz`
--
ALTER TABLE `costumer_status_retchsschutz`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_vorsorge`
--
ALTER TABLE `costumer_status_vorsorge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `costumer_status_zusatzversicherung`
--
ALTER TABLE `costumer_status_zusatzversicherung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deletedlead`
--
ALTER TABLE `deletedlead`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `family_person`
--
ALTER TABLE `family_person`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leads_history`
--
ALTER TABLE `leads_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_a_counteroffered`
--
ALTER TABLE `lead_data_a_counteroffered`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_fahrzeug`
--
ALTER TABLE `lead_data_fahrzeug`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_kk`
--
ALTER TABLE `lead_data_kk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_s`
--
ALTER TABLE `lead_data_s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_data_s_w`
--
ALTER TABLE `lead_data_s_w`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lead_info`
--
ALTER TABLE `lead_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `pendencies`
--
ALTER TABLE `pendencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personalappointment`
--
ALTER TABLE `personalappointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `rejectedleads`
--
ALTER TABLE `rejectedleads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_consultants`
--
ALTER TABLE `team_consultants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `todos`
--
ALTER TABLE `todos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trainings`
--
ALTER TABLE `trainings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_another_item_g`
--
ALTER TABLE `add_another_item_g`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `admin_appointments`
--
ALTER TABLE `admin_appointments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaigns`
--
ALTER TABLE `campaigns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_conversations`
--
ALTER TABLE `chat_conversations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `chat_participation`
--
ALTER TABLE `chat_participation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `costumers`
--
ALTER TABLE `costumers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `costumer_podukt_zusatzversicherung`
--
ALTER TABLE `costumer_podukt_zusatzversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `costumer_produkt_autoversicherung`
--
ALTER TABLE `costumer_produkt_autoversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `costumer_produkt_grundversicherung`
--
ALTER TABLE `costumer_produkt_grundversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `costumer_produkt_hausrat`
--
ALTER TABLE `costumer_produkt_hausrat`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `costumer_produkt_rechtsschutz`
--
ALTER TABLE `costumer_produkt_rechtsschutz`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `costumer_produkt_vorsorge`
--
ALTER TABLE `costumer_produkt_vorsorge`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `costumer_status_grundversicherung`
--
ALTER TABLE `costumer_status_grundversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `costumer_status_hausrat`
--
ALTER TABLE `costumer_status_hausrat`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `costumer_status_retchsschutz`
--
ALTER TABLE `costumer_status_retchsschutz`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `costumer_status_vorsorge`
--
ALTER TABLE `costumer_status_vorsorge`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `costumer_status_zusatzversicherung`
--
ALTER TABLE `costumer_status_zusatzversicherung`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `deletedlead`
--
ALTER TABLE `deletedlead`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `family_person`
--
ALTER TABLE `family_person`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `leads_history`
--
ALTER TABLE `leads_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lead_data_a_counteroffered`
--
ALTER TABLE `lead_data_a_counteroffered`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lead_data_fahrzeug`
--
ALTER TABLE `lead_data_fahrzeug`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lead_data_kk`
--
ALTER TABLE `lead_data_kk`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lead_data_s`
--
ALTER TABLE `lead_data_s`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lead_data_s_w`
--
ALTER TABLE `lead_data_s_w`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lead_info`
--
ALTER TABLE `lead_info`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `pendencies`
--
ALTER TABLE `pendencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personalappointment`
--
ALTER TABLE `personalappointment`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rejectedleads`
--
ALTER TABLE `rejectedleads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `team_consultants`
--
ALTER TABLE `team_consultants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `todos`
--
ALTER TABLE `todos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trainings`
--
ALTER TABLE `trainings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_messages_participation_id_foreign` FOREIGN KEY (`participation_id`) REFERENCES `chat_participation` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `chat_message_notifications`
--
ALTER TABLE `chat_message_notifications`
  ADD CONSTRAINT `chat_message_notifications_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_message_notifications_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `chat_messages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_message_notifications_participation_id_foreign` FOREIGN KEY (`participation_id`) REFERENCES `chat_participation` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_participation`
--
ALTER TABLE `chat_participation`
  ADD CONSTRAINT `chat_participation_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `chat_conversations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
