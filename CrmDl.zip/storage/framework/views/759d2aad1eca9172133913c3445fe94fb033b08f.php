
<?php $__env->startSection('content'); ?>
<style>

  body {
    margin-top: 40px;
    font-size: 14px;
    font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
  }



  #external-events {

  }


  #external-events h4 {
    font-size: 16px;
    margin-top: 0;
    padding-top: 1em;
  }

  #external-events .fc-event {
    margin: 10px 0;
    cursor: pointer;
  }

  #external-events p {
    margin: 1.5em 0;
    font-size: 11px;
    color: #666;
  }

  #external-events p input {
    margin: 0;
    vertical-align: middle;
  }

  #calendar {
    float: left;
    width: 90%;
	text-color : black ;
  }


</style>




<link href='lib_cal/main.css' rel='stylesheet' />
<script src='lib_cal/main.js'></script>
<script src='lib_cal/moment.min.js'></script>
<script src='lib_cal/moment.js'></script>
<script src="https://maps.google.com/maps/api/js?key=AIzaSyDFBE1cuoGyzaiyvog5Zi6-tBvRwyXHiz8" type="text/javascript"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<?php if(Auth::guard('admins')->user()->hasRole('admin') || Auth::guard('admins')->user()->hasRole('salesmanager')): ?>

<script>

  document.addEventListener('DOMContentLoaded', function() {

    /* initialize the external events
    -----------------------------------------------------------------*/

    var containerEl = document.getElementById('external-events');
    new FullCalendar.Draggable(containerEl, {
      itemSelector: '.fc-event',
      eventData: function(eventEl) {
        return {
          title: eventEl.innerText.trim(),

        }
      }
    });

    /* initialize the calendar
    -----------------------------------------------------------------*/

    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {

      now: "<?php echo $date_in->format('Y-m-d'); ?>",
      editable: false, // enable draggable events
      droppable: true, // this allows things to be dropped onto the calendar
      aspectRatio: 1.8,

      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'resourceTimeGridDay,timeGridWeek,dayGridMonth'
      },
	  views: {
			 dayGridMonth: {
			   eventMaxStack: 3
			 },
			 timeGridWeek: {
			   eventMaxStack: 3
			 },

		 },

	  slotLabelFormat: {hour: 'numeric', minute: '2-digit', hour12: false},

	  height: 600,
      initialView: 'resourceTimeGridDay',
	  slotMinTime: "08:00:00",
      slotMaxTime : "20:00:00",
      slotDuration: '00:30:00',
	  slotLabelInterval: 30,
	  allDaySlot : false,
	  eventMaxStack : 3,
      dayMaxEvents : 3,


      resources: [
	  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        { id: '<?php echo $user->id; ?>', title: '<?php echo $user->name; ?>', eventColor: 'green' },
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      ],
      events: [
	  <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointmentAGG): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
		id: '<?php echo $appointmentAGG["id"]; ?>',
		resourceId: '<?php echo $appointmentAGG["assign_to_id"]; ?>',
		title: '<?php echo e($appointmentAGG["first_name"]); ?> <?php echo e($appointmentAGG["last_name"]); ?>',
		start: new Date('<?php echo date("d/M/Y H:i", strtotime($appointmentAGG["appointment_date"]." ".$appointmentAGG["time"])); ?>') ,
		telephone: '<?php echo e($appointmentAGG["telephone"]); ?>' ,
		birthdate: '<?php echo e($appointmentAGG["birthdate"]); ?>' ,
		number_of_persons: '<?php echo e($appointmentAGG["number_of_persons"]); ?>' ,
		nationality: '<?php echo e($appointmentAGG["nationality"]); ?>' ,
		status_task: '<?php echo e($appointmentAGG["status_task"]); ?>' ,
		eventColor: 'green',
		name: '<?php echo e($appointmentAGG["first_name"]); ?> <?php echo e($appointmentAGG["last_name"]); ?>',
		user_to :'<?php echo e($appointmentAGG["assign_to_id"]); ?>',



		},

	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      ],
      drop: function(arg) {
        console.log('drop date: ' + arg.dateStr)

        if (arg.resource) {
          //console.log('drop resource: ' + arg.resource.id);

		  //console.log('eventReceive',arg.draggedEl.innerText.trim());


		  if (confirm('Are you sure you want to assign appointment of ('+arg.draggedEl.innerText.trim()+') to <'+arg.resource.title+'>')) {
		  // Save it!
		  // console.log('Thing was saved to the database.');

		 $.ajax({
                     url: "<?php echo e(URL::route('Dropajax')); ?>"+"?nom_lead="+arg.draggedEl.innerText.trim()+"&id_user="+arg.resource.id+"&time="+arg.draggedEl.now+"&ctime="+calendar.getDate(),
                     type: "GET",
                     data: {"data" : arg.draggedEl.innerText.trim()},
                     success: function(data) {
                          alert(data);
						  window.location.reload();
                                   }
                              });




		  arg.draggedEl.parentNode.removeChild(arg.draggedEl);
		} else {
		  // Do nothing!
		  // console.log('Thing was not saved to the database.');
		  // alert('KO');

		  // remove from calendar
		  arg.remove()
		}
        }


      },
      eventReceive: function(arg) { // called when a proper external event is dropped
        //console.log('eventReceive', arg.event);


      },
      eventDrop: function(arg) { // called when an event (already on the calendar) is moved
        //console.log('eventDrop', arg.event);
      },
	  eventClick: function(calEvent) {

		 document.getElementById("start").innerHTML = moment(calEvent.event.start).format('Y-MM-DD HH:mm');
		 document.getElementById("name").innerHTML = calEvent.event.title;
		 document.getElementById("telephone").innerHTML = calEvent.event.extendedProps.telephone;
		 document.getElementById("birthdate").innerHTML = calEvent.event.extendedProps.birthdate;
		 //document.getElementById("address").innerHTML = calEvent.event.extendedProps.address;
		 document.getElementById("number_of_persons").innerHTML = calEvent.event.extendedProps.number_of_persons;
		 document.getElementById("nationality").innerHTML = calEvent.event.extendedProps.nationality;
		 document.getElementById("status_task").innerHTML = calEvent.event.extendedProps.status_task;
		 document.getElementById("id").innerHTML = calEvent.event.id;
		 document.getElementById("id_lead_input").value = calEvent.event.id;
		 document.getElementById("id_lead_input2").value = calEvent.event.id;
		 document.getElementById("date_new").value = moment(calEvent.event.start).format('Y-MM-DD');
		 document.getElementById("date_new2").value = moment(calEvent.event.start).format('Y-MM-DD');
		 document.getElementById("time_new").value = moment(calEvent.event.start).format('HH:mm');
		 document.getElementById("time_new2").value = moment(calEvent.event.start).format('HH:mm');
		 document.getElementById("OP-"+calEvent.event.extendedProps.user_to).selected = true ;

		 $(exampleModal).modal('show');

	 }
    });
    calendar.render();


  });

</script>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog " role="document " style="max-width: 700px">
    <div class="modal-content">
      <div class="modal-header">
	  <div class="col-md-4" style="text-align : left">
	  <h5 class="modal-title" id="exampleModalLabel">Appointement detail</h5>
	  </div>
	  <div class="col-md-6" style="text-align : center">
	  <h4 style="text-align : center; "><B><span id='start' style=" color : #e57e2d"></span></B> (<span id='number_of_persons'></span>persons)</h4>
	  </div>
	  <div class="col-md-2" style="text-align : right">
	  <h5 class="modal-title"><B>ID :</B><span id='id'></span></h5>
	  </div>

      </div>
      <div class="modal-body">




	    <p style="line-height :8px"><B>Name :</B><span id='name'></span></p>
	    <p style="line-height :8px"><B>Telephone :</B><span id='telephone'></span></p>
	    <p style="line-height :8px"><B>Birthdate :</B><span id='birthdate'></span></p>
	    <p style="line-height :8px"><B>Nationality :</B><span id='nationality'></span></p>
	    <p style="line-height :8px"><B>Status of task :</B><span id='status_task'></span></p>
		<hr>
		<!--<p><B>address :</B><span id='address'></span></p> -->
		<div class="row" >
			<div class="col-md-6" style="text-align : left; ">
			<a href="#" onclick='document.getElementById("change_fs").style.display = "block" ;' class="btn btn-info btn-sm"><i class="far fa-edit"></i> Edit</a>
			</div>
			<div class="col-md-6" style="text-align : right ;">
			<?php echo e(Form::open(array('url' => 'changeTS' , 'method' => 'get'))); ?>

			<input type="hidden"  id="id_lead_input2" name="id_lead_input">
			<input type="hidden"  id="ts_id2" name="ts_id" value="0">
			<input type="hidden"  id="time_new2" name="time_new">
			<input type="hidden"  id="date_new2" name="date_new"><?php echo Form::button('<i class="fas fa-retweet"></i> Replace in appointement list', ['type' => 'submit', 'class' => 'btn btn-warning btn-sm']); ?>

			<?php echo e(Form::close()); ?>

			</div>
			<hr>
		</div>
		<div style="display : none" id="change_fs">
		<?php echo e(Form::open(array('url' => 'changeTS' , 'method' => 'get'))); ?>

		    <input type="hidden" value="" id="id_lead_input" name="id_lead_input">
			<div class="row">
				<div class="form-group col-sm-3">
					<?php echo Form::label('ts_id', 'FS:'); ?>

					<select name="ts_id" id="" class="form-control form-select form-select-sm" required>
						<option value="" id="">*******</option>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo $user->id; ?>" id="OP-<?php echo $user->id; ?>"><?php echo $user->name; ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="form-group col-sm-4">
					<?php echo Form::label('ts_id', 'Date:'); ?>

					<input type="date"  id="date_new" name="date_new" class="form-control form-control-sm" value="" disabled>
				</div>
				<div class="form-group col-sm-2">
					<?php echo Form::label('ts_id', 'Time:'); ?>

					<input type="time"  id="time_new" name="time_new" class="form-control form-control-sm" value="" min="08:00" max="20:00" disabled>
				</div>
				<div class="form-group col-sm-3" style="text-align : rignt">
					<br>
					<?php echo Form::submit('Save', ['class' => 'btn btn-primary btn-sm btn-block']); ?>

					<a class="btn btn-danger btn-sm" href="#" onclick="$(exampleModal).modal('hide'); ">Cancel</a>
				</div>
			</div>
		<?php echo e(Form::close()); ?>

		</div>
      </div>

    </div>
  </div>
</div>

<div class="col-12 col-sm-12 col-md-12  g-0">
           <h3> Appointments </h3>
</div>
<div class="col-12 col-sm-12 col-md-12  g-0">
<?php echo e(Form::open(array('url' => 'Appointments' , 'method' => 'get'))); ?>

<div class="row" style=" padding: 0 10px;border: 1px solid #ccc;width : 98.8%;    background: #eee;  ">
	<div class="col-lg-2"><br>
		<input type="radio" id="html" name="trie" value="desc" <?php if($trie == "desc" ): ?>checked <?php endif; ?>>
		<label for="html"><i class="fas fa-sort-amount-down"></i> Time Desc</label>
	</div>
	<div class="col-lg-2"><br>
		<input type="radio" id="css" name="trie" value="asc" <?php if($trie == "asc" ): ?>checked <?php endif; ?>>
		<label for="css"><i class="fas fa-sort-amount-up-alt"></i> Time Asc</label>
	</div>
	<div class="col-lg-2">
	<label >Date</label>
	<input type="date" class="form-control form-control-sm" name="date_in" value="<?php echo $date_in->format('Y-m-d'); ?>">
	</div>
			<div class="col-lg-2">
				<label >Region</label>
				<select name="region" class="form-control form-select form-select-sm">
					<option value="all" <?php if($regionO == "all"): ?> selected <?php endif; ?>>All region</option>
					<?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo $region->city; ?>" <?php if($regionO == $region->city): ?> selected <?php endif; ?> ><?php echo $region->city; ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="col-lg-1">
				<label >Status</label>
				<select name="rejected" class="form-control form-select form-select-sm">
					<option value="all" <?php if($rejectedO == "all"): ?> selected <?php endif; ?>>All</option>
					<option value="1" <?php if($rejectedO == "1"): ?> selected <?php endif; ?>>Rejected </option>
					<option value="0" <?php if($rejectedO == "0"): ?> selected <?php endif; ?>>Accepted</option>
				</select>
			</div>
			<div class="col-lg-2">
				<label >language</label>
				<select name="sprache" class="form-control form-select form-select-sm">
					<option value="all"  <?php if($spracheO == "all"): ?> selected <?php endif; ?>>All language</option>
					<?php $__currentLoopData = $langues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo $langue->sprache; ?>" <?php if($spracheO == $langue->sprache): ?> selected <?php endif; ?> ><?php echo $langue->sprache; ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select><br>
			</div>
			<div class="col-lg-1"><br>
			<?php echo Form::button('<i class="fas fa-filter"></i>Filter', ['type' => 'submit', 'class' => 'btn btn-success btn-sm btn-block']); ?>

	</div>

</div><?php echo e(Form::close()); ?>


</div>
<div class="col-12 col-sm-12 col-md-12 col-lg-12 g-0"><br>
<div class="row">
	<div class="col-lg-9 col-12" style="font-size: 12px; text-align : center ;">
		 <?php if(session('msg')): ?> <h5 style="color : #212529 ; background-color : #0080003b;"><?php echo session('msg'); ?></h5> <?php session(['msg' => '']); ?> <?php endif; ?>
	</div>

<div class="col-lg-9 col-12" style="font-size: 12px;">
	<div class="mx-2" id='calendar'></div>
    <div style='clear:both'></div>
</div>
<div class="col-lg-3 col-12 box follow-scroll">
    <div id='external-events' >
	<div id='wrap' style="overflow-y: scroll; float: center; padding: 0 10px;border: 1px solid #ccc;width : 90%;    background: #eee;    text-align: left;	height: 600px ;text-align:center">
		<h4> Appointments liste (<?php echo count($appointments_events); ?>) </h4>
	  <hr>
	  <?php $__currentLoopData = $appointments_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($appointment["rejected"] == 0): ?>
      <div class='fc-event' style="margin: 10px 0; cursor: pointer; border: 1px solid #ccc;   font-size: 12px;  background: #f8deca;"><?php echo $appointment["id"]; ?>-<?php echo $appointment['first_name']; ?> <?php echo $appointment['last_name']; ?><br><B style="color: #5e0b0b"><?php echo date("d/M/Y H:i", strtotime($appointment["appointment_date"]." ".$appointment["time"])); ?>(<?php echo $appointment["number_of_persons"]; ?> persons)</B><br><?php if($appointment["assigned"] == '0'): ?><a href='acceptappointment/<?php echo $appointment["id"]; ?>' style="color:red">Not assigned </a><?php endif; ?></div>
      <?php else: ?>
      <div class='fc-event' style="margin: 10px 0; cursor: pointer; border: 1px solid #ccc;   font-size: 12px;  background:rgb(255, 0, 0,0.55);"><?php echo $appointment["id"]; ?>-<?php echo $appointment['first_name']; ?> <?php echo $appointment['last_name']; ?><br><B style="color: #5e0b0b"><?php echo date("d/M/Y H:i", strtotime($appointment["appointment_date"]." ".$appointment["time"])); ?>(<?php echo $appointment["number_of_persons"]; ?> persons)</B><br><?php if($appointment["assigned"] == '0'): ?><a href='acceptappointment/<?php echo $appointment["id"]; ?>' style="color:red">Rejected </a><?php endif; ?></div>
<?php endif; ?>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    </div>
    </div>
</div>
      </div>

	  <div class="row">
            <div class="col-md-12">

                <div class="text-center" style="margin-top: 30px">
                    <a href="<?php echo e(route('insertappointment')); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="37.694" height="37.694" viewBox="0 0 37.694 37.694">
                            <g id="Group_621" data-name="Group 621" transform="translate(-663.236 -976.679)">
                                <g id="Group_550" data-name="Group 550" transform="translate(663.236 976.679)">
                                    <rect id="Rectangle_9" data-name="Rectangle 9" width="37.694" height="37.694" rx="18.847" fill="#4ec590"/>
                                        <g id="Group_42" data-name="Group 42" transform="translate(12.724 12.724)">
                                            <line id="Line_11" data-name="Line 11" y2="11.972" transform="translate(5.986 0)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2"/>
                                            <line id="Line_12" data-name="Line 12" x1="11.972" transform="translate(0 5.634)" fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2"/>
                                        </g>
                                </g>
                            </g>
                        </svg>

                    </a>
                    <br>
                    Add new one
                </div>
            </div>
            <div class="col-md-12">
                <section>
                    <div class="container">
                        <div class="form-div my-4 py-4 mx-auto" style="background-color: #EFEFEF; border-radius: 20px;">
                            <div class="mb-4 mx-5">
                                <span class="fs-5 fw-600">Or Insert By File</span>
                            </div>
                            <form method="post" action="<?php echo e(route('addappointmentfile')); ?>" enctype="multipart/form-data">
                                <div class="row mx-4">
                                    <div class="col">
                                        <div class="mx-2">
                                            <div class="input-group">
                                                <input type="file" class="form-control" name="file">
                                            </div>
                                            <div class="my-4">
                                                <button type="submit" class="py-2 px-5 border-0 fw-bold"
                                                        style="background-color: #63D4A4; color: #fff; border-radius: 8px;">Accept</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div onclick="openExamplePic()">
                                <span class="btn fw-600 mx-5" style="border: 1px solid #434343;border-radius: 5px">Example</span>
                            </div>
                            <br>
                            <div style="display: none" class="w-100" id="picture">
                                <img src="exceExample.png" alt="pic" class="img-fluid">
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <script type="text/javascript">
            function openExamplePic() {
                var x = document.getElementById('picture');
                if (x.style.display == 'none') {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
            }
        </script>





<?php elseif(Auth::guard('admins')->user()->hasRole('fs')): ?>


<script>

    /* initialize the calendar
    -----------------------------------------------------------------*/

  document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendar');

  var calendar = new FullCalendar.Calendar(calendarEl, {


      editable: false, // enable draggable events
      droppable: true, // this allows things to be dropped onto the calendar
      aspectRatio: 1.8,
      scrollTime: '00:00', // undo default 6am scrollTime


		headerToolbar: {
		  left: 'prev,next today',
		  center: 'title',
		  right: 'timeGridWeek,timeGridDay,dayGridMonth'
		},
		views: {
			 dayGridMonth: {
			   eventMaxStack: 3
			 }
		 },
		initialView: 'timeGridWeek',


		eventMaxStack : 3,
		dayMaxEvents : 3,
		height: 600,
		  slotMinTime: "08:00:00",
		  slotMaxTime : "20:00:00",
		  slotDuration: '00:30:00',
		  slotLabelInterval: 30,
		  allDaySlot : false,
    events: [
	  <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointmentAGG): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
		id: '<?php echo $appointmentAGG["id"]; ?>',
		start: new Date('<?php echo date("d/M/Y H:i", strtotime($appointmentAGG["appointment_date"]." ".$appointmentAGG["time"])); ?>') ,
		telephone: '<?php echo e($appointmentAGG["telephone"]); ?>' ,
		birthdate: '<?php echo e($appointmentAGG["birthdate"]); ?>' ,
		number_of_persons: '<?php echo e($appointmentAGG["number_of_persons"]); ?>' ,
		nationality: '<?php echo e($appointmentAGG["nationality"]); ?>' ,
		status_task: '<?php echo e($appointmentAGG["status_task"]); ?>' ,
		eventColor: 'green',
		name: '<?php echo e($appointmentAGG["first_name"]); ?> <?php echo e($appointmentAGG["last_name"]); ?>',
		title: '<?php echo e($appointmentAGG["first_name"]); ?> <?php echo e($appointmentAGG["last_name"]); ?>',
		address: '',
		},

	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      ],

	 eventClick: function(calEvent) {

		 document.getElementById("start").innerHTML = moment(calEvent.event.start).format('Y-m-d HH:mm');
		 document.getElementById("name").innerHTML = calEvent.event.title;
		 document.getElementById("telephone").innerHTML = calEvent.event.extendedProps.telephone;
		 document.getElementById("birthdate").innerHTML = calEvent.event.extendedProps.birthdate;
		 document.getElementById("address").innerHTML = calEvent.event.extendedProps.address;
		 document.getElementById("number_of_persons").innerHTML = calEvent.event.extendedProps.number_of_persons;
		 document.getElementById("nationality").innerHTML = calEvent.event.extendedProps.nationality;
		 document.getElementById("status_task").innerHTML = calEvent.event.extendedProps.status_task;
		 document.getElementById("id").innerHTML = calEvent.event.id;

		 $(exampleModal).modal('show');

	 },

  });

  calendar.render();
});

</script>
<!-- Button trigger modal


 -->



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Appointement detail</h5>
      </div>
      <div class="modal-body">

	    <h5 style="text-align : center; "><B><span id='start' style=" color : #e57e2d"></span></B> (<span id='number_of_persons'></span> persons  )</h5>

	    <p><B>ID :</B><span id='id'></span></p>
	    <p><B>Name :</B><span id='name'></span></p>
	    <p><B>Telephone :</B><span id='telephone'></span></p>
	    <p><B>Birthdate :</B><span id='birthdate'></span></p>
	    <p><B>Nationality :</B><span id='nationality'></span></p>
	    <p><B>Status of task :</B><span id='status_task'></span></p>
		<hr>
		<p><B>address :</B><span id='address'></span></p>
      </div>

    </div>
  </div>
</div>




<div class="col-12">
           <h3> Appointments</h3>
</div>

<div class="col-12" width="90%" style="font-size: 12px;">
    <div class="mx-2" id='calendar'></div>
</div>
<div class="gmap_canvas">

            <div id="map"  style="z-index: 0 !important;width: 90% !important; height:70vh !important; border-radius: 15px !important;"></div>

        </div>








<script type="text/javascript">
    var locations = [
        ['Bondi Beach', -33.890542, 151.274856, 4],
        ['Coogee Beach', -33.923036, 151.259052, 5],
        ['Cronulla Beach', -34.028249, 151.157507, 3],
        ['Manly Beach', -33.80010128657071, 151.28747820854187, 2],
        ['Maroubra Beach', -33.950198, 151.259302, 1]
    ];

    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 10,
        center: new google.maps.LatLng(-33.92, 151.25),
        mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map
        });

        google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
                infowindow.setContent(locations[i][0]);
                infowindow.open(map, marker);
            }
        })(marker, i));
    }
</script>




<?php else: ?>

You don't have permission // <?php echo Auth::guard('admins')->user()->hasRole('admin'); ?> ---  <?php echo Auth::guard('admins')->user()->getRoleNames(); ?>



<?php endif; ?>
<?php $__env->stopSection(); ?>

<style>

    body{
        overflow-x: hidden !important;
    }
</style>

<style>
    .mapouter {
        position: relative;
    }

    .gmap_canvas {
        overflow: hidden;
        background: none !important;
    }

    .scroll-2 {
        height: 380px !important;
    }

    .calendar-divider {
        background-color: #efefef !important;
        border-radius: 15px !important;
    }

    .fw-600 {
        font-weight: 600;
    }

    .notice-box {
        background-color: #FFEBE5;
        border-radius: 35px;
    }

    .person-box-1 {
        background-color: #fff;
        border-radius: 15px;
    }

    .input-group select {
        border-radius: 7px !important;
        box-shadow: none !important;
    }

    .calendar-box {
        background-color: #EFEFEF;
        border-radius: 35px;
    }

    .person-box {
        color: #fff;
        font-weight: 600;
        border-radius: 15px;
        background-color: #4EC590;
    }

    .title-div {
        color: #5F5F5F;
        font-weight: 600;
    }

    body {
        overflow-x: hidden !important;
    }
</style>
<style>
    /*Per Notification */
    .coloriii a{
        color: black !important;
    }
</style>

<?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CrmDl\resources\views/appointment.blade.php ENDPATH**/ ?>