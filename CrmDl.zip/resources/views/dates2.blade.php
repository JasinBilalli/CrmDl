<html>
@extends('template.navbar')
@section('content')

<p>gg</p>
@endsection
</html>
