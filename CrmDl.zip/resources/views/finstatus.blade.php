@extends('template.navbar')
@section('content')
@endsection