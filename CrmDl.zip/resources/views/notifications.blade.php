@foreach($notifications as $not)
{!! $not->data !!}

@endforeach
<style>
    /*Per Notification */
    .coloriii a{
        color: black !important;
    }
</style>
