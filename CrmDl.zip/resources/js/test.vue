<template>
    



    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

    <div class="container-fluid">
        <div class="row ">
            <div class="col-lg-12 g-0">
                <div class="card chat-app">
                    <div id="plist" class="people-list">
                        <div class="search-notif fixed-top " style="width:320px">
                            <div class="row px-2 g-0">
                                <div class="col g-0">
                                    <div class="d-flex p-2" style="align-items: center;">
                                        <div class="input-group">
                                            <div class="my-auto btn search-icon ps-3 pe-2">
                                                <span class="">
                                                    <i class="fa fa-search"></i>
                                                </span>
                                            </div>
                                            <input type="text" class="form-control" placeholder="Search Notifications">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-auto my-auto">
                                    <div class="message-page-button text-end pe-2">
                                        <button class="btn  bg-white" style="font-weight: 500;"
                                            onclick="showMssgFunct()">
                                            Messages
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="px-2 sectionn "
                            style="width: 319px; margin-bottom: 119px; bottom: 0; position: fixed;">
                            <ul class="list-unstyled chat-list overflow-11 my-2 pe-1"
                                style="overflow: auto; height: 90vh; padding-top: 120px;">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                                <li class="clearfix py-2 px-0">
                                    <!-- <img src="https://bootdey.com/img/Content/avatar/avatar1.png" alt="avatar">  -->
                                    <div class="about">
                                        <div class="name">Lorem Ipsum</div>
                                        <div class="status py-1"> Lorem ipsum dolor sit
                                            amet, consectetuer adipiscing elit
                                        </div>
                                        <div class="status-time">
                                            Yesterday, 13:30pm
                                        </div>
                                    </div>
                                </li>
                                <hr class="m-0 g-0 p-0">
                            </ul>
                        </div>
                        <div class="new-message-divv fixed-bottom d-flex justify-content-center">
                            <div class="">
                                <button class="btn-dark bg-white button-new-msg px-3 py-2 btn text-dark">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" viewBox="0 0 28.789 29.329">
                                        <g id="Group_1070" data-name="Group 1070" transform="translate(0)">
                                            <path id="Path_1959" data-name="Path 1959"
                                                d="M28.721,1.257A.915.915,0,0,0,27.531.066L.865,10.733a1.375,1.375,0,0,0-.229,2.436l9.158,5.825,2.8,4.41a.917.917,0,0,0,1.549-.983l-2.524-3.963L25.361,4.722l-3.472,8.685a.916.916,0,1,0,1.686.717l.013-.035ZM24.065,3.426,10.33,17.163,2.374,12.1,24.065,3.426"
                                                transform="translate(0)" fill="#535353" />
                                            <path id="Path_1960" data-name="Path 1960"
                                                d="M21.536,15.416A6.416,6.416,0,1,1,15.121,9a6.417,6.417,0,0,1,6.416,6.416M15.121,11.75a.917.917,0,0,0-.917.917V14.5H12.371a.917.917,0,1,0,0,1.833H14.2v1.833a.917.917,0,1,0,1.833,0V16.332H17.87a.917.917,0,0,0,0-1.833H16.037V12.666a.917.917,0,0,0-.917-.917"
                                                transform="translate(7.252 7.498)" fill="#535353" />
                                        </g>
                                    </svg>
                                    <span class="ps-2">New Notifications</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="chat " id="chatt">
                        <div class="chat-header clearfix fixed-top" style="margin-left:321px; align-items: center;">
                            <div class="row">
                                <div class="col col-lg-6">
                                    <div class="d-flex p-2" style="align-items: center;">
                                        <div class="col-auto mx-2"
                                            style="width: 40px;height: 40px;border-radius: 50%;background-color: #fff;border:1px #70707080 solid;">
                                        </div>
                                        <div class="chat-about my-auto ">
                                            <div class="my-auto">lorem Ipsum</div>
                                            <!-- <small>Last seen: 2 hours ago</small>   -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-auto my-auto">
                                    <div class="notify-page-button text-end pe-2">
                                        <button class="btn bg-white" style="font-weight: 500;"
                                            onclick="showNotifFunct()">
                                            Notifications
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                      
                        <div class="chat-message fixed-bottom p-3">
                            <div class="row">
                                <div class="col">
                                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                                </div>
                                <div class="col-auto g-0">
                                    <button type="button" class="btn send-button px-2 py-2 px-md-5 mb-1 m-md-1 py-md-1">
                                        <span class="desktop-send">Send</span>
                                        <span class="mobile-send">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" fill="currentColor"
                                                class="bi bi-send" viewBox="0 0 16 16">
                                                <path
                                                    d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576 6.636 10.07Zm6.787-8.201L1.591 6.602l4.339 2.76 7.494-7.493Z" />
                                            </svg>
                                        </span>
                                    </button>
                                    <br>
                                    <button type="button" class="btn send-button px-2 py-2 px-md-3 m-md-1 py-md-1">
                                        <span class="desktop-send">
                                            Send File
                                            <svg xmlns="http://www.w3.org/2000/svg" width="22" fill="currentColor"
                                                class="bi bi-file-earmark-image" viewBox="0 0 16 16">
                                                <path d="M6.502 7a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z" />
                                                <path
                                                    d="M14 14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5V14zM4 1a1 1 0 0 0-1 1v10l2.224-2.224a.5.5 0 0 1 .61-.075L8 11l2.157-3.02a.5.5 0 0 1 .76-.063L13 10V4.5h-2A1.5 1.5 0 0 1 9.5 3V1H4z" />
                                            </svg>
                                        </span>
                                        <span class="mobile-send">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" fill="currentColor"
                                                class="bi bi-file-earmark-image" viewBox="0 0 16 16">
                                                <path d="M6.502 7a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z" />
                                                <path
                                                    d="M14 14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5V14zM4 1a1 1 0 0 0-1 1v10l2.224-2.224a.5.5 0 0 1 .61-.075L8 11l2.157-3.02a.5.5 0 0 1 .76-.063L13 10V4.5h-2A1.5 1.5 0 0 1 9.5 3V1H4z" />
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                                <!-- <span class="form-control input-text-22" id="exampleFormControlTextarea1" contenteditable
                                    placeholder="Enter text here..." rows=" "></span> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <style>
        .new-message-divv {
            align-items: center;
            height: 119px;
            background-color: #fff;
            width: 320px
        }

        .send-button {
            background-color: #0C71C3;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 17px;
            font-weight: bold;
        }

        .send-button:hover {
            color: #fff;
        }

        .input-text-22 {
            max-height: 53px;
        }

        .button-new-msg {
            color: #535353;
            box-shadow: rgba(17, 17, 26, 0.1) 0px 0px 16px;
            border: 1px #535353 solid;
            border-radius: 10px;
        }

        .sectionn {
            border-bottom: 1px solid #70707080
        }

        .overflow-11::-webkit-scrollbar {
            width: 5px;
        }

        /* Track */
        .overflow-11::-webkit-scrollbar-track {
            background: #EFEFEF !important;
            border-radius: 10px;
        }

        /* Handle */
        .overflow-11::-webkit-scrollbar-thumb {
            background: #0C71C380;
            border-radius: 10px;
        }

        /* Handle on hover */
        .overflow-11::-webkit-scrollbar-thumb:hover {
            background: #0C71C3;
            border-radius: 10px;
        }







        .overflow-22::-webkit-scrollbar {
            width: 5px;
        }

        /* Track */
        .overflow-22::-webkit-scrollbar-track {
            background: #EFEFEF !important;
            border-radius: 10px;
        }

        /* Handle */
        .overflow-22::-webkit-scrollbar-thumb {
            background: #0C71C380;
            border-radius: 10px;
        }

        /* Handle on hover */
        .overflow-22::-webkit-scrollbar-thumb:hover {
            background: #0C71C3;
            border-radius: 10px;
        }


        .status-time {
            font-weight: 600;
            font-size: 11px;
            color: #A7A7A7;
        }

        .search-notif {
            background-color: #EFEFEF;
            height: 65px;
            border-bottom: 1px solid #70707080;
        }

        .search-icon {
            color: #0C71C3;
            background-color: #fff;
            border: 1px solid #ced4da;
            border-right: none;
            border-radius: 10px;
        }

        .form-control {
            border-color: #ced4da !important;
            box-shadow: none !important;
        }

        .send-file input[type="file"] {
            display: none;
        }

        body {
            font-family: montserrat;
        }

        .card {
            background: #fff;
            transition: .5s;
            border: 0;
            /* margin-bottom: 30px; */
            border-radius: .55rem;
            position: relative;
            width: 100%;
            /* box-shadow: 0 1px 2px 0 rgb(0 0 0 / 10%); */
        }

        .chat-app .people-list {
            width: 320px;
            position: absolute;
            left: 0;
            top: 0;

            z-index: 7;
            background-color: #fff;
        }

        .chat-app .people-list ul li:hover {
            background-color: #EFEFEF;
        }

        .chat-app .chat {
            margin-left: 320px;
            border-left: 1px solid #70707080;
            height: 100vh;
        }

        .people-list {
            -moz-transition: .5s;
            -o-transition: .5s;
            -webkit-transition: .5s;
            transition: .5s;
            height: 100vh;
        }

        .people-list .chat-list li {
            padding: 10px 15px;
            list-style: none;
            border-radius: 3px;
        }

        .people-list .chat-list li:hover {
            background: #fff;
            cursor: pointer;
        }

        .people-list .chat-list li.active {
            background: #fff;
        }

        .people-list .chat-list li .name {
            font-size: 17px;
            color: #0C71C3;
            font-weight: 500;
        }


        .people-list .chat-list img {
            width: 45px;
            border-radius: 50%;
        }

        .people-list img {
            float: left;
            border-radius: 50%;
        }

        .people-list .about {
            float: left;
            padding-left: 8px;
        }

        .people-list .status {
            color: #434343;
            font-size: 11px;
        }

        .chat .chat-header {
            height: 65px;
            border-bottom: 1px solid #70707080;
            background-color: #EFEFEF;
        }

        .chat .chat-header img {
            float: left;
            border-radius: 40px;
            width: 40px;
        }

        .chat .chat-header .chat-about {
            float: left;
            padding-left: 10px;
            font-weight: 500;
        }

        .chat .chat-history {
            padding: 20px;
            border-bottom: 2px solid #fff;
            background-color: #fff;
        }

        .chat .chat-history ul {
            padding: 0;
        }

        .chat .chat-history ul li {
            list-style: none;
            margin-bottom: 30px;
        }

        .chat .chat-history ul li:last-child {
            margin-bottom: 0px;
        }

        .chat .chat-history .message-data {
            margin-bottom: 15px;
        }

        .chat .chat-history .message-data img {
            border-radius: 40px;
            width: 40px;
        }

        .chat .chat-history .message-data-time {
            color: #434651;
            padding-left: 6px;
        }

        .chat .chat-history .message {
            color: #444;
            padding: 8px 20px;
            line-height: 1.5;
            font-size: 14px;
            border-radius: 8px;
            display: inline-block;
            position: relative;
            max-width: 65%;
        }

        /* .chat .chat-history .message:after {
            bottom: 100%;
            left: 7%;
            border: solid transparent;
            content: " ";
            height: 0;
            width: 0;
            position: absolute;
            pointer-events: none;
            border-bottom-color: #fff;
            border-width: 10px;
            margin-left: -10px
        } */

        .chat .chat-history .my-message {
            background: #fff;
            border: 0.5px solid #70707080;
            border-radius: 8px;

        }

        /* .chat .chat-history .my-message:after {
            bottom: 100%;
            left: 30px;
            border: solid transparent;
            content: " ";
            height: 0;
            width: 0;
            position: absolute;
            pointer-events: none;
            border-bottom-color: #efefef;
            border-width: 10px;
            margin-left: -10px
        } */

        .chat .chat-history .other-message {
            background: #0C71C3;
            color: #fff;
            text-align: right;
        }

        .chat .chat-history .other-message:after {
            border-bottom-color: #e8f1f3;
            left: 93%;
        }

        .chat .chat-message {
            margin-left: 320px;
            height: 120px;
            background-color: #F7F7F7;
            border-top: 1px #70707080 solid;
            border-left: 1px #70707080 solid;
        }

        .online,
        .offline,
        .me {
            margin-right: 2px;
            font-size: 8px;
            vertical-align: middle;
        }

        .online {
            color: #86c541;
        }

        .offline {
            color: #9b9b9b;
        }

        .me {
            color: #1d8ecd;
        }

        .float-right {
            float: right;
        }

        .clearfix:after {
            visibility: hidden;
            display: block;
            font-size: 0;
            content: " ";
            clear: both;
            height: 0;
        }

        .desktop-send {
            display: block;
        }

        .mobile-send {
            display: none;
        }

        .message-page-button {
            display: none;
        }

        .notify-page-button {
            display: none;
        }

        .people-list {
            display: block;
        }

        .chat {
            display: block;
        }

        @media only screen and (max-width: 767px) {
            .chat-app .people-list {
                height: 465px;
                width: 100%;
                overflow-x: auto;
                background: #fff;
                /* left: -400px; */
                display: none;
            }

            .chat {
                display: block;
            }

            .sectionn {
                width: 100% !important;
            }

            .search-notif {
                width: 100% !important;
            }

            .new-message-divv {
                width: 100%;
            }

            .chat-app .people-list.open {
                left: 0;
            }

            .desktop-send {
                display: none;
            }

            .mobile-send {
                display: block;
            }

            .notify-page-button {
                display: block;
            }

            .message-page-button {
                display: block;
            }

            .chat-app .chat {
                margin: 0;
                border: none;

            }

            .chat-app .chat .chat-header {
                /* border-radius: 0.55rem 0.55rem 0 0; */
                margin-left: 0 !important;
            }

            .chat-app .chat-history {
                height: 300px;
                overflow-x: auto;
            }

            .chat .chat-history .message {
                max-width: 80%;
            }

            .chat-message {
                margin-left: 0 !important;
            }
        }

        @media only screen and (min-width: 768px) and (max-width: 992px) {
            .chat-app .chat-list {
                height: 650px;
                overflow-x: auto;
            }

            .chat-app .chat-history {
                height: 600px;
                overflow-x: auto;
            }
        }

        @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1) {
            .chat-app .chat-list {
                height: 480px;
                overflow-x: auto;
            }

            .chat-app .chat-history {
                height: calc(100vh - 350px);
                overflow-x: auto;
            }
        }
    </style>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <script>
        function showMssgFunct() {
            document.getElementById('plist').style.display = "none";
            document.getElementById('chatt').style.display = "block";
        }
        function showNotifFunct() {
            document.getElementById('chatt').style.display = "none";
            document.getElementById("plist").style.display = "block";
        }

    </script>

</body>

</html>