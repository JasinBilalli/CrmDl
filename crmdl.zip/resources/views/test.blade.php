{{__('lang.test',['name' => 'Albenit'])}}
