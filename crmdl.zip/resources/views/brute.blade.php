<script>
    var fjala = 'flor';
    var aja = 'a';
    a
</script>
