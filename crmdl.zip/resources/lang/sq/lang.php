<?php

return [
    'test' => 'Pershendetje :name'
];
?>
